// driver.h

#include <systemc.h>

SC_MODULE(driver)
{
    sc_out<bool> t;
    sc_out<bool> clk;

    // Clock toggles every 5 ns
    void inputs_clock()
    {
        while (true)
        {
            clk.write(0);
            wait(5, SC_NS);

            clk.write(1);
            wait(5, SC_NS);
        }
    }

    // T input stimulus (independent timing)
    void inputs_TFF()
    {
        t.write(1);
        wait(4, SC_NS);

        t.write(0);
        wait(8, SC_NS);

        t.write(1);
        wait(5, SC_NS);

        t.write(0);
        wait(8, SC_NS);

        t.write(1);
        wait(5, SC_NS);

        t.write(0);
        wait(6, SC_NS);

        t.write(1);
        wait(14, SC_NS);

        t.write(0);
        wait(12, SC_NS);

        t.write(1);
        wait(9, SC_NS);

        t.write(0);
        wait(6, SC_NS);

        t.write(1);
        wait(10, SC_NS);

        t.write(1);
        wait(5, SC_NS);

        t.write(0);
        wait(8, SC_NS);

        sc_stop();   // Properly placed inside function
    }

    SC_CTOR(driver)
    {
        SC_THREAD(inputs_clock);
        SC_THREAD(inputs_TFF);
    }
};
