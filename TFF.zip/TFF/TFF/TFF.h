// TFF.h

#include <systemc.h>

SC_MODULE(TFF)
{
    sc_in<bool> clk;
    sc_in<bool> t;
    sc_out<bool> q;

    bool state;   // Internal state

    void compute_tff()
    {
        if (t.read() == 1)
            state = !state;   // Toggle when T = 1

        q.write(state);
    }

    SC_CTOR(TFF)
    {
        state = 0;   // Initial value

        SC_METHOD(compute_tff);
        sensitive << clk.pos();   // Trigger on positive edge
    }
};
