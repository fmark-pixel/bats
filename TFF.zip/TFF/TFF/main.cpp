// main.cpp

#include <systemc.h>
#include "TFF.h"
#include "driver.h"

int sc_main(int argc, char* argv[])
{
    sc_signal<bool> t, clk, q;

    TFF tff("tff");
    driver drive("driver");

    // Port connections
    tff.clk(clk);
    tff.t(t);
    tff.q(q);

    drive.clk(clk);
    drive.t(t);

    // Waveform (GTKWave)
    sc_trace_file* Tf;
    Tf = sc_create_vcd_trace_file("traces");

    sc_trace(Tf, clk, "clk");
    sc_trace(Tf, t,   "t");
    sc_trace(Tf, q,   "q");

    sc_start(70, SC_NS);

    sc_close_vcd_trace_file(Tf);
    return 0;
}
