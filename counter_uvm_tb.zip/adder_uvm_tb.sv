// ============================================================
// UVM Testbench for 4-bit Adder
// DUT: adder(a, b, cin, sum, cout)
// ============================================================

`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================
// INTERFACE
// ============================================================
interface adder_if (input logic clk);
  logic [3:0] a, b;
  logic       cin;
  logic [3:0] sum;
  logic       cout;
endinterface

// ============================================================
// DUT (simple combinational adder)
// ============================================================
module adder (
  input  logic [3:0] a, b,
  input  logic       cin,
  output logic [3:0] sum,
  output logic       cout
);
  assign {cout, sum} = a + b + cin;
endmodule

// ============================================================
// SEQUENCE ITEM (transaction)
// ============================================================
class adder_seq_item extends uvm_sequence_item;
  `uvm_object_utils(adder_seq_item)

  rand logic [3:0] a, b;
  rand logic       cin;
  logic [3:0] sum;
  logic       cout;

  function new(string name = "adder_seq_item");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("a=%0d b=%0d cin=%0b | sum=%0d cout=%0b",
                     a, b, cin, sum, cout);
  endfunction
endclass

// ============================================================
// SEQUENCE
// ============================================================
class adder_seq extends uvm_sequence #(adder_seq_item);
  `uvm_object_utils(adder_seq)

  function new(string name = "adder_seq");
    super.new(name);
  endfunction

  task body();
    adder_seq_item item;
    repeat(20) begin
      item = adder_seq_item::type_id::create("item");
      start_item(item);
      assert(item.randomize());
      finish_item(item);
    end
  endtask
endclass

// ============================================================
// DRIVER
// ============================================================
class adder_driver extends uvm_driver #(adder_seq_item);
  `uvm_component_utils(adder_driver)

  virtual adder_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db #(virtual adder_if)::get(this, "", "vif", vif))
      `uvm_fatal("NO_VIF", "Virtual interface not found")
  endfunction

  task run_phase(uvm_phase phase);
    adder_seq_item item;
    forever begin
      seq_item_port.get_next_item(item);
      @(posedge vif.clk);
      vif.a   = item.a;
      vif.b   = item.b;
      vif.cin = item.cin;
      #1; // allow combinational logic to settle
      seq_item_port.item_done();
    end
  endtask
endclass

// ============================================================
// MONITOR
// ============================================================
class adder_monitor extends uvm_monitor;
  `uvm_component_utils(adder_monitor)

  virtual adder_if vif;
  uvm_analysis_port #(adder_seq_item) ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db #(virtual adder_if)::get(this, "", "vif", vif))
      `uvm_fatal("NO_VIF", "Virtual interface not found")
  endfunction

  task run_phase(uvm_phase phase);
    adder_seq_item item;
    forever begin
      @(posedge vif.clk); #1;
      item      = adder_seq_item::type_id::create("item");
      item.a    = vif.a;
      item.b    = vif.b;
      item.cin  = vif.cin;
      item.sum  = vif.sum;
      item.cout = vif.cout;
      ap.write(item);
    end
  endtask
endclass

// ============================================================
// SCOREBOARD
// ============================================================
class adder_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(adder_scoreboard)

  uvm_analysis_imp #(adder_seq_item, adder_scoreboard) imp;
  int pass_count, fail_count;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
  endfunction

  function void write(adder_seq_item item);
    logic [4:0] exp = item.a + item.b + item.cin;
    if ({item.cout, item.sum} === exp) begin
      `uvm_info("SB", $sformatf("PASS: %s", item.convert2string()), UVM_LOW)
      pass_count++;
    end else begin
      `uvm_error("SB", $sformatf("FAIL: %s | expected sum=%0d cout=%0b",
                 item.convert2string(), exp[3:0], exp[4]))
      fail_count++;
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SB", $sformatf("Results: PASS=%0d FAIL=%0d",
              pass_count, fail_count), UVM_NONE)
  endfunction
endclass

// ============================================================
// AGENT
// ============================================================
class adder_agent extends uvm_agent;
  `uvm_component_utils(adder_agent)

  adder_driver    drv;
  adder_monitor   mon;
  uvm_sequencer #(adder_seq_item) seqr;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    drv  = adder_driver::type_id::create("drv", this);
    mon  = adder_monitor::type_id::create("mon", this);
    seqr = uvm_sequencer #(adder_seq_item)::type_id::create("seqr", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    drv.seq_item_port.connect(seqr.seq_item_export);
  endfunction
endclass

// ============================================================
// ENVIRONMENT
// ============================================================
class adder_env extends uvm_env;
  `uvm_component_utils(adder_env)

  adder_agent      agt;
  adder_scoreboard sb;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agt = adder_agent::type_id::create("agt", this);
    sb  = adder_scoreboard::type_id::create("sb", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    agt.mon.ap.connect(sb.imp);
  endfunction
endclass

// ============================================================
// TEST
// ============================================================
class adder_test extends uvm_test;
  `uvm_component_utils(adder_test)

  adder_env env;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = adder_env::type_id::create("env", this);
  endfunction

  task run_phase(uvm_phase phase);
    adder_seq seq = adder_seq::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(env.agt.seqr);
    #10;
    phase.drop_objection(this);
  endtask
endclass

// ============================================================
// TOP MODULE (testbench wrapper)
// ============================================================
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  logic clk;
  initial clk = 0;
  always #5 clk = ~clk;

  adder_if dut_if (.clk(clk));

  adder dut (
    .a   (dut_if.a),
    .b   (dut_if.b),
    .cin (dut_if.cin),
    .sum (dut_if.sum),
    .cout(dut_if.cout)
  );

  initial begin
    uvm_config_db #(virtual adder_if)::set(null, "uvm_test_top.*", "vif", dut_if);
    run_test("adder_test");
  end
endmodule
