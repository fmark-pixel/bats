// ============================================================
// UVM Testbench for 4-bit Up Counter
// DUT: counter(clk, rst_n, en, count)
// ============================================================

`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================
// INTERFACE
// ============================================================
interface counter_if (input logic clk);
  logic       rst_n;
  logic       en;
  logic [3:0] count;
endinterface

// ============================================================
// DUT (synchronous up counter with enable)
// ============================================================
module counter (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       en,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)    count <= 4'h0;
    else if (en)   count <= count + 1;
  end
endmodule

// ============================================================
// SEQUENCE ITEM
// ============================================================
class counter_seq_item extends uvm_sequence_item;
  `uvm_object_utils(counter_seq_item)

  rand logic rst_n;
  rand logic en;
  logic [3:0] count;  // output captured by monitor

  // Mostly keep reset de-asserted; pulse low rarely
  constraint c_rst { rst_n dist {1 := 90, 0 := 10}; }

  function new(string name = "counter_seq_item");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("rst_n=%0b en=%0b count=%0d", rst_n, en, count);
  endfunction
endclass

// ============================================================
// SEQUENCE
// ============================================================
class counter_seq extends uvm_sequence #(counter_seq_item);
  `uvm_object_utils(counter_seq)

  function new(string name = "counter_seq");
    super.new(name);
  endfunction

  task body();
    counter_seq_item item;
    // Step 1: assert reset for 3 cycles
    repeat(3) begin
      item = counter_seq_item::type_id::create("item");
      start_item(item);
      item.rst_n = 0; item.en = 0;
      finish_item(item);
    end
    // Step 2: release reset and run 20 random cycles
    repeat(20) begin
      item = counter_seq_item::type_id::create("item");
      start_item(item);
      assert(item.randomize() with { rst_n == 1; });
      finish_item(item);
    end
  endtask
endclass

// ============================================================
// DRIVER
// ============================================================
class counter_driver extends uvm_driver #(counter_seq_item);
  `uvm_component_utils(counter_driver)

  virtual counter_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db #(virtual counter_if)::get(this, "", "vif", vif))
      `uvm_fatal("NO_VIF", "Virtual interface not found")
  endfunction

  task run_phase(uvm_phase phase);
    counter_seq_item item;
    // Safe initial state
    vif.rst_n = 0; vif.en = 0;
    forever begin
      seq_item_port.get_next_item(item);
      @(posedge vif.clk);
      vif.rst_n = item.rst_n;
      vif.en    = item.en;
      seq_item_port.item_done();
    end
  endtask
endclass

// ============================================================
// MONITOR
// ============================================================
class counter_monitor extends uvm_monitor;
  `uvm_component_utils(counter_monitor)

  virtual counter_if vif;
  uvm_analysis_port #(counter_seq_item) ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db #(virtual counter_if)::get(this, "", "vif", vif))
      `uvm_fatal("NO_VIF", "Virtual interface not found")
  endfunction

  task run_phase(uvm_phase phase);
    counter_seq_item item;
    forever begin
      @(posedge vif.clk); #1;
      item       = counter_seq_item::type_id::create("item");
      item.rst_n = vif.rst_n;
      item.en    = vif.en;
      item.count = vif.count;
      ap.write(item);
    end
  endtask
endclass

// ============================================================
// SCOREBOARD
// ============================================================
class counter_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(counter_scoreboard)

  uvm_analysis_imp #(counter_seq_item, counter_scoreboard) imp;

  logic [3:0] exp_count;
  int pass_count, fail_count;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp       = new("imp", this);
    exp_count = 4'h0;
  endfunction

  function void write(counter_seq_item item);
    // Update reference model
    if (!item.rst_n)        exp_count = 4'h0;
    else if (item.en)       exp_count = exp_count + 1;
    // Note: monitor samples AFTER DUT, so compare directly
    if (item.count === exp_count) begin
      `uvm_info("SB", $sformatf("PASS: %s", item.convert2string()), UVM_LOW)
      pass_count++;
    end else begin
      `uvm_error("SB", $sformatf("FAIL: %s | expected count=%0d",
                 item.convert2string(), exp_count))
      fail_count++;
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SB", $sformatf("Results: PASS=%0d FAIL=%0d",
              pass_count, fail_count), UVM_NONE)
  endfunction
endclass

// ============================================================
// AGENT
// ============================================================
class counter_agent extends uvm_agent;
  `uvm_component_utils(counter_agent)

  counter_driver  drv;
  counter_monitor mon;
  uvm_sequencer #(counter_seq_item) seqr;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    drv  = counter_driver::type_id::create("drv", this);
    mon  = counter_monitor::type_id::create("mon", this);
    seqr = uvm_sequencer #(counter_seq_item)::type_id::create("seqr", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    drv.seq_item_port.connect(seqr.seq_item_export);
  endfunction
endclass

// ============================================================
// ENVIRONMENT
// ============================================================
class counter_env extends uvm_env;
  `uvm_component_utils(counter_env)

  counter_agent      agt;
  counter_scoreboard sb;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agt = counter_agent::type_id::create("agt", this);
    sb  = counter_scoreboard::type_id::create("sb", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    agt.mon.ap.connect(sb.imp);
  endfunction
endclass

// ============================================================
// TEST
// ============================================================
class counter_test extends uvm_test;
  `uvm_component_utils(counter_test)

  counter_env env;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = counter_env::type_id::create("env", this);
  endfunction

  task run_phase(uvm_phase phase);
    counter_seq seq = counter_seq::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(env.agt.seqr);
    #10;
    phase.drop_objection(this);
  endtask
endclass

// ============================================================
// TOP MODULE
// ============================================================
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  logic clk;
  initial clk = 0;
  always #5 clk = ~clk;

  counter_if dut_if (.clk(clk));

  counter dut (
    .clk  (clk),
    .rst_n(dut_if.rst_n),
    .en   (dut_if.en),
    .count(dut_if.count)
  );

  initial begin
    uvm_config_db #(virtual counter_if)::set(null, "uvm_test_top.*", "vif", dut_if);
    run_test("counter_test");
  end
endmodule
