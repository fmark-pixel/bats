class scoreboard;
  mailbox mon2scb;
  function new(mailbox mon2scb);
    this.mon2scb=mon2scb;
  endfunction
  
  task main();
    transaction trans;
    repeat(5)
      begin
        mon2scb.get(trans);
        trans.display("scoreboard signals");
        if(((trans.a^trans.b^trans.c)==trans.sum)&&(((trans.a&trans.b)|(trans.c&trans.a)|(trans.b&trans.c))==trans.carry))
          $display("PASS");
      else
        $display("FAIL");
      end
  endtask
endclass
  