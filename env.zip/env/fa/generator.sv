class generator;
  transaction trans;
  mailbox gen2drv;
  function new(mailbox gen2drv);
    this.gen2drv=gen2drv;
  endfunction
  
  task main();
    repeat(5)
      begin
        trans=new();
        assert(trans.randomize());
        trans.display("generation class signals");
        gen2drv.put(trans);
      end
  endtask
endclass