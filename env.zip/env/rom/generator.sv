class generator;
  mailbox gen2drv;
  transaction trans;

  function new(mailbox gen2drv);
    this.gen2drv = gen2drv;
  endfunction

  task main();
    repeat(20) begin // Verify 20 random locations
      trans = new();
      assert(trans.randomize()); 
      gen2drv.put(trans);
    end
  endtask
endclass