class driver;
  virtual rom_if vif;
  mailbox gen2drv;
  transaction trans;

  function new(virtual rom_if vif, mailbox gen2drv);
    this.vif = vif;
    this.gen2drv = gen2drv;
  endfunction

  task main();
    vif.en <= 0; // Disable initially
    
    forever begin
      gen2drv.get(trans);
      
      @(posedge vif.clk);
      vif.en <= 1;          // Enable ROM
      vif.addr <= trans.addr; // Apply Address
      
      // Wait for the read cycle to complete
      // We hold the address long enough for the Monitor to see it + Data
      @(posedge vif.clk); 
      
      trans.display("DRV");
    end
  endtask
endclass