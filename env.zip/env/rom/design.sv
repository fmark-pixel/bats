module rom #(parameter DEPTH=16, WIDTH=8) (
  input  logic clk,
  input  logic en,
  input  logic [$clog2(DEPTH)-1:0] addr,
  output logic [WIDTH-1:0] data
);
  
  // The Memory Array
  logic [WIDTH-1:0] mem [DEPTH-1:0];

  // Initialize ROM with a known pattern (e.g., Content = Index + 1)
  // In real life, this would be $readmemh("file.hex", mem);
  initial begin
    foreach(mem[i]) begin
      mem[i] = i + 1; 
    end
  end

  // Synchronous Read Logic
  always_ff @(posedge clk) begin
    if (en)
      data <= mem[addr];
    else
      data <= 'z; // High Impedance if disabled
  end

endmodule