class monitor;
  virtual rom_if vif;
  mailbox mon2scb;
  transaction trans;

  function new(virtual rom_if vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction

  task main();
    forever begin
      @(posedge vif.clk);
      // Sample only if ROM was enabled
      if (vif.en) begin
        // Note: In a real pipeline, we might need to capture Address from T0
        // and Data from T1. For simplicity here, we assume the Driver holds
        // the address stable during the read.
        trans = new();
        trans.addr = vif.addr;
        trans.data = vif.data;
        
        mon2scb.put(trans);
        trans.display("MON");
      end
    end
  endtask
endclass