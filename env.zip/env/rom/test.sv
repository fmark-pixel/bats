`include "environment.sv"
program test(rom_if vif);
  environment env;
  initial begin
    env = new(vif);
    env.test_run();
    #300 $finish;
  end
endprogram