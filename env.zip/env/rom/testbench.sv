`include "interface.sv"
`include "test.sv"

module tbench_top;
  bit clk;
  always #5 clk = ~clk;

  rom_if intf(clk);
  
  rom DUT (
    .clk(intf.clk),
    .en(intf.en),
    .addr(intf.addr),
    .data(intf.data)
  );
  
  test t1(intf);
  
  initial begin
    $dumpfile("rom.vcd"); $dumpvars;
  end
endmodule