class transaction;
  // Stimulus: Random address
  rand bit [3:0] addr;
  
  // Response: The data we read back
  bit [7:0] data;

  function void display(string name);
    $display("[%s] Addr=%0d, Data=%0d", name, addr, data);
  endfunction
endclass