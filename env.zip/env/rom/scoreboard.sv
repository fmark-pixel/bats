class scoreboard;
  mailbox mon2scb;
  transaction trans;
  bit [7:0] expected_data;

  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
  endfunction

  task main();
    forever begin
      mon2scb.get(trans);
      
      // GOLDEN MODEL: Calculate what should be in the ROM
      // In design.sv, we did: mem[i] = i + 1;
      expected_data = trans.addr + 1; 

      if (trans.data == expected_data) begin
        $display("[SCB] PASS: Addr=%0d Data=%0d", trans.addr, trans.data);
      end else begin
        $error("[SCB] FAIL: Addr=%0d Expected=%0d Got=%0d", 
               trans.addr, expected_data, trans.data);
      end
    end
  endtask
endclass