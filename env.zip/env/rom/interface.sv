interface rom_if(input logic clk);
  logic en;
  logic [3:0] addr;
  logic [7:0] data;
endinterface