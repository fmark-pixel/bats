class monitor;
  virtual intf vif;
  mailbox mon2scb;

  function new(virtual intf vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction

  task main();
    transaction trans;
    trans=new();
    forever begin
      @(posedge vif.clk);
      trans.reset = vif.reset;
      trans.count = vif.count;
      mon2scb.put(trans);
      trans.display("MON");
    end
  endtask
endclass
