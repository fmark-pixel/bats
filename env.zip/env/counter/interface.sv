interface intf(input logic clk);
  logic reset;
  logic [3:0] count;
endinterface
