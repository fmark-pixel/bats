class transaction;
  rand bit reset;
  bit [3:0] count;

  function void display(string name);
    $display("%s: reset=%0b count=%0d", name, reset, count);
  endfunction
endclass
