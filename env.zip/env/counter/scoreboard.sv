class scoreboard;
  mailbox mon2scb;
  bit [3:0] expected = 0;

  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
  endfunction

  task main();
    transaction trans;
    forever begin
      mon2scb.get(trans);

      if (trans.reset)
        expected = 0;
      else
        expected++;

      if (trans.count == expected)
        $display("SCB: PASS");
      else
        $display("SCB: FAIL expected=%0d got=%0d", expected, trans.count);
    end
  endtask
endclass
