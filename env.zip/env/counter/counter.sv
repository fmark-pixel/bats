module counter #(parameter N=4)(
  input logic clk,
  input logic reset,
  output logic [N-1:0] count
);
  always @(posedge clk) begin
    if (reset)
      count <= '0;
    else
      count <= count + 1;
  end
endmodule
