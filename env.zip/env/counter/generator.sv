class generator;
  mailbox gen2drv;
  transaction trans;

  function new(mailbox gen2drv);
    this.gen2drv = gen2drv;
  endfunction

  task main();
    repeat(20) begin
      trans = new();
      assert(trans.randomize());
      trans.display("GEN");
      gen2drv.put(trans);
    end
  endtask
endclass
