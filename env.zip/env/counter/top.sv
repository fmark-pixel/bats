`include "interface.sv"
`include "test.sv"

module testbench;
  logic clk = 0;
  always #1 clk = ~clk;

  intf intff(clk);
  test t(intff);

  counter DUT(.clk(clk), .reset(intff.reset), .count(intff.count));

  initial begin
    $dumpfile("counter.vcd");
    $dumpvars(0, testbench);
    #100 $finish;
  end
endmodule