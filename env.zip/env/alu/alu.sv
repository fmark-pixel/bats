// alu.sv
module alu(
  input [3:0] a,
  input [3:0] b,
  input [2:0] opcode,
  output reg [3:0] result,
  output reg zero,
  output reg carry
);
  
  always @(*) begin
    carry = 0;
    case(opcode)
      3'b000: {carry, result} = a + b;        // ADD
      3'b001: {carry, result} = a - b;        // SUB
      3'b010: result = a & b;                  // AND
      3'b011: result = a | b;                  // OR
      3'b100: result = a ^ b;                  // XOR
      3'b101: result = ~a;                     // NOT
      3'b110: result = a << 1;                 // SLL (Shift Left Logical)
      3'b111: result = a >> 1;                 // SRL (Shift Right Logical)
      default: result = 4'b0000;
    endcase
    zero = (result == 0) ? 1'b1 : 1'b0;
  end
  
endmodule
