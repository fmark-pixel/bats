// interface.sv
interface intf();
  logic [3:0] a;
  logic [3:0] b;
  logic [2:0] opcode;
  logic [3:0] result;
  logic zero;
  logic carry;
endinterface
