// transaction.sv
class transaction;
  rand bit [3:0] a;
  rand bit [3:0] b;
  rand bit [2:0] opcode;
  bit [3:0] result;
  bit zero;
  bit carry;
  
  function void display(string name);
    $display("%s", name);
    $display("a=%0d, b=%0d, opcode=%0b, result=%0d, zero=%0b, carry=%0b", 
             a, b, opcode, result, zero, carry);
  endfunction
endclass
