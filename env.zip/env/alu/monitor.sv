// monitor.sv
class monitor;
  virtual intf vif;
  mailbox mon2scb;
  
  function new(virtual intf vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction
  
  task main();
    repeat(20)
      #1
      begin
        transaction trans;
        trans = new();
        trans.a = vif.a;
        trans.b = vif.b;
        trans.opcode = vif.opcode;
        trans.result = vif.result;
        trans.zero = vif.zero;
        trans.carry = vif.carry;
        mon2scb.put(trans);
        trans.display("Monitor Class Signals");
      end
  endtask
endclass
