// scoreboard.sv
class scoreboard;
  mailbox mon2scb;
  
  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
  endfunction
  
  task main();
    transaction trans;
    bit [4:0] expected_result;
    bit expected_zero;
    bit expected_carry;
    
    repeat(20)
      begin
        mon2scb.get(trans);
        trans.display("Scoreboard Signals");
        
        // Calculate expected outputs
        case(trans.opcode)
          3'b000: begin // ADD
            expected_result = trans.a + trans.b;
            expected_carry = expected_result[4];
            expected_result = expected_result[3:0];
          end
          3'b001: begin // SUB
            expected_result = trans.a - trans.b;
            expected_carry = expected_result[4];
            expected_result = expected_result[3:0];
          end
          3'b010: begin // AND
            expected_result = trans.a & trans.b;
            expected_carry = 0;
          end
          3'b011: begin // OR
            expected_result = trans.a | trans.b;
            expected_carry = 0;
          end
          3'b100: begin // XOR
            expected_result = trans.a ^ trans.b;
            expected_carry = 0;
          end
          3'b101: begin // NOT
            expected_result = ~trans.a;
            expected_carry = 0;
          end
          3'b110: begin // SLL
            expected_result = trans.a << 1;
            expected_carry = 0;
          end
          3'b111: begin // SRL
            expected_result = trans.a >> 1;
            expected_carry = 0;
          end
          default: begin
            expected_result = 4'b0000;
            expected_carry = 0;
          end
        endcase
        
        expected_zero = (expected_result == 0) ? 1'b1 : 1'b0;
        
        // Check results
        if((trans.result == expected_result) && 
           (trans.zero == expected_zero) && 
           (trans.carry == expected_carry))
          $display("PASS");
        else
          $display("FAIL - Expected: result=%0d, zero=%0b, carry=%0b", 
                   expected_result, expected_zero, expected_carry);
      end
  endtask
endclass
