// generator.sv
class generator;
  transaction trans;
  mailbox gen2drv;
  
  function new(mailbox gen2drv);
    this.gen2drv = gen2drv;
  endfunction
  
  task main();
    repeat(20)
      begin
        trans = new();
        assert(trans.randomize());
        trans.display("Generator Class Signals");
        gen2drv.put(trans);
      end
  endtask
endclass
