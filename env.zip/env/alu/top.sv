// top.sv
`include "interface.sv"
`include "test.sv"

module testbench;
  intf intff();
  test tst(intff);
  
  alu ALU(
    .a(intff.a),
    .b(intff.b),
    .opcode(intff.opcode),
    .result(intff.result),
    .zero(intff.zero),
    .carry(intff.carry)
  );
  
  initial begin
    $dumpfile("dump.vcd");
    $dumpvars(0, testbench);
  end
endmodule
