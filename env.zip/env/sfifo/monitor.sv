class monitor;
  virtual fifo_if vif;
  mailbox mon2scb;
  transaction trans;

  function new(virtual fifo_if vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction

  task main();
    forever begin
      @(posedge vif.clk);
      // We only want to capture valid operations
      if (vif.wr_en || vif.rd_en) begin
        trans = new();
        trans.wr_en = vif.wr_en;
        trans.rd_en = vif.rd_en;
        trans.data_in = vif.data_in;
        trans.data_out = vif.data_out; // Capture output
        trans.full = vif.full;
        trans.empty = vif.empty;
        
        mon2scb.put(trans);
        trans.display("MON");
      end
    end
  endtask
endclass