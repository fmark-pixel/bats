class scoreboard;
  mailbox mon2scb;
  transaction trans;
  bit [7:0] queue[$]; // SystemVerilog Queue to mimic FIFO
  bit [7:0] expected_data;

  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
  endfunction

  task main();
    forever begin
      mon2scb.get(trans);
      
      // 1. Logic for WRITE
      if (trans.wr_en) begin
        if (queue.size() < 16) begin
          queue.push_back(trans.data_in);
          $display("[SCB] Pushed: %0d", trans.data_in);
        end else begin
           $display("[SCB] FIFO FULL! Write ignored.");
        end
      end
      
      // 2. Logic for READ
      if (trans.rd_en) begin
        if (queue.size() > 0) begin 
          expected_data = queue.pop_front();
          
          if (trans.data_out == expected_data) 
            $display("[SCB] PASS: Read %0d", trans.data_out);
          else 
            $error("[SCB] FAIL: Expected %0d, Got %0d", expected_data, trans.data_out);
            
        end else begin
           $display("[SCB] FIFO EMPTY! Read ignored.");
        end
      end
    end
  endtask
endclass