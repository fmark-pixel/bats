class generator;
  mailbox gen2drv;
  transaction trans;

  function new(mailbox gen2drv);
    this.gen2drv = gen2drv;
  endfunction

  task main();
    repeat(50) begin // Test 50 operations
      trans = new();
      assert(trans.randomize()); 
      gen2drv.put(trans);
    end
  endtask
endclass