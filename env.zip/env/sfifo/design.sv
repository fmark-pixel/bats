module fifo #(parameter DEPTH=16, WIDTH=8) (
  input  logic clk,
  input  logic rst,
  input  logic wr_en,
  input  logic rd_en,
  input  logic [WIDTH-1:0] data_in,
  output logic [WIDTH-1:0] data_out,
  output logic full,
  output logic empty
);
  
  logic [WIDTH-1:0] mem [DEPTH-1:0];
  logic [$clog2(DEPTH)-1:0] wr_ptr, rd_ptr;
  logic [$clog2(DEPTH):0] count; // Extra bit for full/empty logic

  always_ff @(posedge clk) begin
    if (rst) begin
      wr_ptr <= 0;
      rd_ptr <= 0;
      count <= 0;
      data_out <= 0;
    end else begin
      // Write Operation
      if (wr_en && !full) begin
        mem[wr_ptr] <= data_in;
        wr_ptr <= wr_ptr + 1;
        count <= count + 1;
      end
      
      // Read Operation
      if (rd_en && !empty) begin
        data_out <= mem[rd_ptr];
        rd_ptr <= rd_ptr + 1;
        count <= count - 1;
      end
    end
  end

  assign full = (count == DEPTH);
  assign empty = (count == 0);

endmodule