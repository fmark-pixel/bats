class transaction;
  rand bit wr_en;
  rand bit rd_en;
  rand bit [7:0] data_in;
  
  bit [7:0] data_out;
  bit full;
  bit empty;

  constraint wr_rd_c { wr_en != rd_en; } 

  constraint dist_c { wr_en dist {1:/60, 0:/40}; }

  function void display(string name);
    $display("[%s] wr=%0b rd=%0b din=%0d dout=%0d full=%0b empty=%0b", 
             name, wr_en, rd_en, data_in, data_out, full, empty);
  endfunction
endclass