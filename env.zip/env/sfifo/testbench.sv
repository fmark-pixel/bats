`include "interface.sv"
`include "test.sv"

module tbench_top;
  bit clk;
  always #5 clk = ~clk;

  fifo_if intf(clk);
  
  fifo DUT (
    .clk(intf.clk),
    .rst(intf.rst),
    .wr_en(intf.wr_en),
    .rd_en(intf.rd_en),
    .data_in(intf.data_in),
    .data_out(intf.data_out),
    .full(intf.full),
    .empty(intf.empty)
  );
  
  test t1(intf);
  
  initial begin
    $dumpfile("dump.vcd"); $dumpvars;
  end
endmodule