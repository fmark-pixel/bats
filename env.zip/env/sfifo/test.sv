`include "environment.sv"
program test(fifo_if vif);
  environment env;
  initial begin
    env = new(vif);
    
    // Reset Sequence
    vif.rst <= 1;
    #10 vif.rst <= 0;
    
    env.test_run();
    #500 $finish;
  end
endprogram