class driver;
  virtual fifo_if vif;
  mailbox gen2drv;
  transaction trans;

  function new(virtual fifo_if vif, mailbox gen2drv);
    this.vif = vif;
    this.gen2drv = gen2drv;
  endfunction

  task main();
    // Initialize signals
    vif.wr_en <= 0;
    vif.rd_en <= 0;
    vif.data_in <= 0;

    forever begin
      gen2drv.get(trans);
      
      @(posedge vif.clk); // Synchronize to clock
      
      // Drive Inputs
      vif.wr_en <= trans.wr_en;
      vif.rd_en <= trans.rd_en;
      vif.data_in <= trans.data_in;
      
      // Wait for operation to complete
      @(posedge vif.clk);
      
      // Return to Idle
      vif.wr_en <= 0;
      vif.rd_en <= 0;
      
      trans.display("DRV");
    end
  endtask
endclass