//========================================
// UVM TESTBENCH TEMPLATE - COMPLETE STRUCTURE
//========================================

`include "uvm_macros.svh"
import uvm_pkg::*;

//========================================
// 1. TYPEDEFS AND PARAMETERS
//========================================
typedef enum {READ, WRITE} optype_t;

//========================================
// 2. TRANSACTION CLASS (SEQUENCE ITEM)
//========================================
class my_transaction extends uvm_sequence_item;
  rand bit [7:0] addr;
  rand bit [7:0] data;
  rand optype_t op_type;
  bit [7:0] read_data;
  
  `uvm_object_utils_begin(my_transaction)
    `uvm_field_int(addr, UVM_DEFAULT)
    `uvm_field_int(data, UVM_DEFAULT)
    `uvm_field_enum(optype_t, op_type, UVM_DEFAULT)
    `uvm_field_int(read_data, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "my_transaction");
    super.new(name);
  endfunction
  
  // Optional: Add constraints
  constraint addr_range { addr inside {[0:15]}; }
  constraint data_range { data inside {[0:255]}; }
  
endclass

//========================================
// 3. SEQUENCE (Transaction Generator)
//========================================
class my_sequence extends uvm_sequence #(my_transaction);
  `uvm_object_utils(my_sequence)
  
  function new(string name = "my_sequence");
    super.new(name);
  endfunction
  
  task body();
    my_transaction txn;
    repeat(10) begin
      txn = my_transaction::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize()) begin
        `uvm_error("RAND_FAIL", "Randomization failed")
      end
      finish_item(txn);
      `uvm_info("SEQ", $sformatf("Generated txn: addr=%0d, data=%0d, op=%s", 
                                  txn.addr, txn.data, txn.op_type), UVM_MEDIUM)
    end
  endtask
  
endclass

//========================================
// 4. SEQUENCER
//========================================
class my_sequencer extends uvm_sequencer #(my_transaction);
  `uvm_component_utils(my_sequencer)
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
endclass

//========================================
// 5. DRIVER
//========================================
class my_driver extends uvm_driver #(my_transaction);
  `uvm_component_utils(my_driver)
  
  virtual dut_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual dut_if)::get(this, "", "dut_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface found")
  endfunction
  
  task run_phase(uvm_run_phase phase);
    my_transaction txn;
    forever begin
      seq_item_port.get_next_item(txn);
      drive_transaction(txn);
      seq_item_port.item_done();
    end
  endtask
  
  task drive_transaction(my_transaction txn);
    @(posedge vif.clk);
    vif.addr = txn.addr;
    vif.data = txn.data;
    vif.we = (txn.op_type == WRITE) ? 1 : 0;
    vif.re = (txn.op_type == READ) ? 1 : 0;
    @(posedge vif.clk);
    vif.we = 0;
    vif.re = 0;
    `uvm_info("DRV", $sformatf("Drove txn: addr=%0d, data=%0d", txn.addr, txn.data), UVM_MEDIUM)
  endtask
  
endclass

//========================================
// 6. MONITOR
//========================================
class my_monitor extends uvm_monitor;
  `uvm_component_utils(my_monitor)
  
  virtual dut_if vif;
  uvm_analysis_port #(my_transaction) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual dut_if)::get(this, "", "dut_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface found")
  endfunction
  
  task run_phase(uvm_run_phase phase);
    my_transaction txn;
    forever begin
      @(posedge vif.clk);
      if(vif.we || vif.re) begin
        txn = my_transaction::type_id::create("txn");
        txn.addr = vif.addr;
        txn.data = vif.data;
        txn.read_data = vif.q;
        ap.write(txn);
        `uvm_info("MON", $sformatf("Monitored txn: addr=%0d, data=%0d, q=%0d", 
                                    txn.addr, txn.data, txn.read_data), UVM_MEDIUM)
      end
    end
  endtask
  
endclass

//========================================
// 7. SCOREBOARD (Checker)
//========================================
class my_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(my_scoreboard)
  
  uvm_analysis_imp #(my_transaction, my_scoreboard) ap_imp;
  bit [7:0] mem [bit [7:0]];
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(my_transaction txn);
    if(txn.op_type == WRITE) begin
      mem[txn.addr] = txn.data;
      `uvm_info("SB", $sformatf("WRITE: addr=%0d, data=%0d", txn.addr, txn.data), UVM_MEDIUM)
    end
    else begin
      if(mem[txn.addr] === txn.read_data) begin
        `uvm_info("SB", $sformatf("READ PASS: addr=%0d, expected=%0d, got=%0d", 
                                   txn.addr, mem[txn.addr], txn.read_data), UVM_MEDIUM)
      end
      else begin
        `uvm_error("SB", $sformatf("READ FAIL: addr=%0d, expected=%0d, got=%0d", 
                                    txn.addr, mem[txn.addr], txn.read_data))
      end
    end
  endfunction
  
endclass

//========================================
// 8. AGENT
//========================================
class my_agent extends uvm_agent;
  `uvm_component_utils(my_agent)
  
  my_sequencer sequencer;
  my_driver driver;
  my_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = my_sequencer::type_id::create("sequencer", this);
    driver = my_driver::type_id::create("driver", this);
    monitor = my_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
  
endclass

//========================================
// 9. ENVIRONMENT
//========================================
class my_env extends uvm_env;
  `uvm_component_utils(my_env)
  
  my_agent agent;
  my_scoreboard scoreboard;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = my_agent::type_id::create("agent", this);
    scoreboard = my_scoreboard::type_id::create("scoreboard", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(scoreboard.ap_imp);
  endfunction
  
endclass

//========================================
// 10. TEST
//========================================
class my_test extends uvm_test;
  `uvm_component_utils(my_test)
  
  my_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = my_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    my_sequence seq;
    phase.raise_objection(this);
    seq = my_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
  
endclass

//========================================
// 11. TESTBENCH TOP MODULE
//========================================
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  // Clock and Reset
  bit clk, rst;
  
  // DUT Interface
  dut_if dut_if_inst(clk);
  
  // DUT Instance (replace with your actual DUT)
  // your_dut dut_inst(.clk(clk), .rst(rst), ...);
  
  initial begin
    // Set virtual interface in config_db
    uvm_config_db#(virtual dut_if)::set(null, "*", "dut_if", dut_if_inst);
    
    // Run tests
    run_test("my_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
  
endmodule

//========================================
// 12. INTERFACE
//========================================
interface dut_if(input bit clk);
  logic rst;
  logic [7:0] addr;
  logic [7:0] data;
  logic we, re;
  logic [7:0] q;
  
  // Optional: Add clocking block for synchronization
  clocking cb @(posedge clk);
    output addr, data, we, re;
    input q;
  endclocking
  
  modport dut_mp (input clk, rst, addr, data, we, re, output q);
  modport tb_mp (clocking cb, output rst);
  
endinterface
