//========================================
// SIMPLE COUNTER RTL (4-bit)
//========================================
module counter_4bit (
  input clk, rst,
  input enable, load,
  input [3:0] load_val,
  output reg [3:0] count
);
  
  always @(posedge clk or posedge rst) begin
    if(rst) begin
      count <= 4'b0000;
    end
    else if(load) begin
      count <= load_val;
    end
    else if(enable) begin
      count <= count + 1;
    end
  end
  
endmodule

//========================================
// COUNTER UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

// Counter Transaction
class counter_txn extends uvm_sequence_item;
  rand bit enable;
  rand bit load;
  rand bit [3:0] load_val;
  bit [3:0] count_val;
  
  `uvm_object_utils_begin(counter_txn)
    `uvm_field_bit(enable, UVM_DEFAULT)
    `uvm_field_bit(load, UVM_DEFAULT)
    `uvm_field_int(load_val, UVM_DEFAULT)
    `uvm_field_int(count_val, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "counter_txn");
    super.new(name);
  endfunction
  
  constraint load_xor_enable {
    !(load && enable);
  }
endclass

// Counter Sequence
class counter_sequence extends uvm_sequence #(counter_txn);
  `uvm_object_utils(counter_sequence)
  
  function new(string name = "counter_sequence");
    super.new(name);
  endfunction
  
  task body();
    counter_txn txn;
    repeat(15) begin
      txn = counter_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("CNT_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// Counter Driver
class counter_driver extends uvm_driver #(counter_txn);
  `uvm_component_utils(counter_driver)
  virtual counter_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual counter_if)::get(this, "", "counter_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    counter_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.enable = txn.enable;
      vif.load = txn.load;
      vif.load_val = txn.load_val;
      seq_item_port.item_done();
    end
  endtask
endclass

// Counter Monitor
class counter_monitor extends uvm_monitor;
  `uvm_component_utils(counter_monitor)
  virtual counter_if vif;
  uvm_analysis_port #(counter_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual counter_if)::get(this, "", "counter_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    counter_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = counter_txn::type_id::create("txn");
      txn.enable = vif.enable;
      txn.load = vif.load;
      txn.load_val = vif.load_val;
      txn.count_val = vif.count;
      ap.write(txn);
    end
  endtask
endclass

// Counter Scoreboard
class counter_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(counter_scoreboard)
  uvm_analysis_imp #(counter_txn, counter_scoreboard) ap_imp;
  bit [3:0] expected_count = 0;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(counter_txn txn);
    if(txn.load) begin
      expected_count = txn.load_val;
      `uvm_info("CNT_SB", $sformatf("LOAD: load_val=%0d", txn.load_val), UVM_MEDIUM)
    end
    else if(txn.enable) begin
      expected_count = (expected_count + 1) % 16;
    end
    
    if(expected_count === txn.count_val)
      `uvm_info("CNT_SB", $sformatf("COUNT PASS: expected=%0d, got=%0d", 
                                    expected_count, txn.count_val), UVM_MEDIUM)
    else
      `uvm_error("CNT_SB", $sformatf("COUNT FAIL: expected=%0d, got=%0d", 
                                     expected_count, txn.count_val))
  endfunction
endclass

// Counter Agent
class counter_agent extends uvm_agent;
  `uvm_component_utils(counter_agent)
  uvm_sequencer #(counter_txn) sequencer;
  counter_driver driver;
  counter_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(counter_txn)::type_id::create("sequencer", this);
    driver = counter_driver::type_id::create("driver", this);
    monitor = counter_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// Counter Environment
class counter_env extends uvm_env;
  `uvm_component_utils(counter_env)
  counter_agent agent;
  counter_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = counter_agent::type_id::create("agent", this);
    sb = counter_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// Counter Test
class counter_test extends uvm_test;
  `uvm_component_utils(counter_test)
  counter_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = counter_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    counter_sequence seq;
    phase.raise_objection(this);
    seq = counter_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface counter_if(input clk);
  logic rst;
  logic enable, load;
  logic [3:0] load_val;
  logic [3:0] count;
endinterface

// Testbench
module tb_counter;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  counter_if counter_if_inst(clk);
  
  counter_4bit dut(.clk(clk), .rst(rst), .enable(counter_if_inst.enable),
                   .load(counter_if_inst.load), .load_val(counter_if_inst.load_val),
                   .count(counter_if_inst.count));
  
  initial begin
    uvm_config_db#(virtual counter_if)::set(null, "*", "counter_if", counter_if_inst);
    run_test("counter_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
