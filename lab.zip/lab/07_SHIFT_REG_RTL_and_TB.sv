//========================================
// SIMPLE SHIFT REGISTER RTL (8-bit)
//========================================
module shift_reg_8bit (
  input clk, rst,
  input serial_in,
  input shift_en,
  output reg serial_out,
  output reg [7:0] parallel_out
);
  
  reg [7:0] shift_reg;
  
  always @(posedge clk or posedge rst) begin
    if(rst) begin
      shift_reg <= 8'b0;
      serial_out <= 0;
    end
    else begin
      if(shift_en) begin
        shift_reg <= {shift_reg[6:0], serial_in};
        serial_out <= shift_reg[7];
      end
    end
  end
  
  assign parallel_out = shift_reg;
  
endmodule

//========================================
// SHIFT REGISTER UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

// Shift Register Transaction
class shift_txn extends uvm_sequence_item;
  rand bit serial_in;
  rand bit shift_en;
  bit serial_out;
  bit [7:0] parallel_out;
  
  `uvm_object_utils_begin(shift_txn)
    `uvm_field_bit(serial_in, UVM_DEFAULT)
    `uvm_field_bit(shift_en, UVM_DEFAULT)
    `uvm_field_bit(serial_out, UVM_DEFAULT)
    `uvm_field_int(parallel_out, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "shift_txn");
    super.new(name);
  endfunction
endclass

// Shift Register Sequence
class shift_sequence extends uvm_sequence #(shift_txn);
  `uvm_object_utils(shift_sequence)
  
  function new(string name = "shift_sequence");
    super.new(name);
  endfunction
  
  task body();
    shift_txn txn;
    repeat(20) begin
      txn = shift_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("SHIFT_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// Shift Register Driver
class shift_driver extends uvm_driver #(shift_txn);
  `uvm_component_utils(shift_driver)
  virtual shift_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual shift_if)::get(this, "", "shift_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    shift_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.serial_in = txn.serial_in;
      vif.shift_en = txn.shift_en;
      seq_item_port.item_done();
    end
  endtask
endclass

// Shift Register Monitor
class shift_monitor extends uvm_monitor;
  `uvm_component_utils(shift_monitor)
  virtual shift_if vif;
  uvm_analysis_port #(shift_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual shift_if)::get(this, "", "shift_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    shift_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = shift_txn::type_id::create("txn");
      txn.serial_in = vif.serial_in;
      txn.shift_en = vif.shift_en;
      txn.serial_out = vif.serial_out;
      txn.parallel_out = vif.parallel_out;
      ap.write(txn);
    end
  endtask
endclass

// Shift Register Scoreboard
class shift_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(shift_scoreboard)
  uvm_analysis_imp #(shift_txn, shift_scoreboard) ap_imp;
  bit [7:0] expected_reg = 8'b0;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(shift_txn txn);
    if(txn.shift_en) begin
      // Check serial output
      if(expected_reg[7] === txn.serial_out)
        `uvm_info("SHIFT_SB", $sformatf("SERIAL OUT PASS: expected=%0b, got=%0b", 
                                        expected_reg[7], txn.serial_out), UVM_MEDIUM)
      else
        `uvm_error("SHIFT_SB", $sformatf("SERIAL OUT FAIL: expected=%0b, got=%0b", 
                                         expected_reg[7], txn.serial_out))
      
      // Shift register
      expected_reg = {expected_reg[6:0], txn.serial_in};
    end
    
    // Check parallel output
    if(expected_reg === txn.parallel_out)
      `uvm_info("SHIFT_SB", $sformatf("PARALLEL PASS: expected=%08b, got=%08b", 
                                      expected_reg, txn.parallel_out), UVM_MEDIUM)
    else
      `uvm_error("SHIFT_SB", $sformatf("PARALLEL FAIL: expected=%08b, got=%08b", 
                                       expected_reg, txn.parallel_out))
  endfunction
endclass

// Shift Register Agent
class shift_agent extends uvm_agent;
  `uvm_component_utils(shift_agent)
  uvm_sequencer #(shift_txn) sequencer;
  shift_driver driver;
  shift_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(shift_txn)::type_id::create("sequencer", this);
    driver = shift_driver::type_id::create("driver", this);
    monitor = shift_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// Shift Register Environment
class shift_env extends uvm_env;
  `uvm_component_utils(shift_env)
  shift_agent agent;
  shift_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = shift_agent::type_id::create("agent", this);
    sb = shift_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// Shift Register Test
class shift_test extends uvm_test;
  `uvm_component_utils(shift_test)
  shift_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = shift_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    shift_sequence seq;
    phase.raise_objection(this);
    seq = shift_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface shift_if(input clk);
  logic rst;
  logic serial_in;
  logic shift_en;
  logic serial_out;
  logic [7:0] parallel_out;
endinterface

// Testbench
module tb_shift;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  shift_if shift_if_inst(clk);
  
  shift_reg_8bit dut(.clk(clk), .rst(rst), .serial_in(shift_if_inst.serial_in),
                     .shift_en(shift_if_inst.shift_en), 
                     .serial_out(shift_if_inst.serial_out),
                     .parallel_out(shift_if_inst.parallel_out));
  
  initial begin
    uvm_config_db#(virtual shift_if)::set(null, "*", "shift_if", shift_if_inst);
    run_test("shift_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
