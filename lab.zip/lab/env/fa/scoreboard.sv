class scoreboard;
  mailbox mon2scb;
   
  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
  endfunction
   
  task main();
    transaction trans;
    
    forever begin
      mon2scb.get(trans);
      trans.display("scoreboard signals");
      
      if( {trans.carry, trans.sum} == (trans.a + trans.b + trans.c) )
        $display("SCOREBOARD: PASS");
      else
        $display("SCOREBOARD: FAIL");
        
    end
  endtask
endclass