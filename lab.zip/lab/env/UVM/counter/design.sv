module counter (
  input clk, reset, load,
  input [3:0] data_in,
  output reg [3:0] count
);
  always @(posedge clk) begin
    if (reset) count <= 4'b0;
    else if (load) count <= data_in;
    else count <= count + 1;
  end
endmodule

interface cnt_if(input logic clk);
  logic reset, load;
  logic [3:0] data_in;
  logic [3:0] count;
endinterface