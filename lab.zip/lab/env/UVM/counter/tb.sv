`include "uvm_macros.svh"
import uvm_pkg::*;

// --- Transaction ---
class cnt_item extends uvm_sequence_item;
  rand bit reset, load;
  rand bit [3:0] data_in;
  bit [3:0] count;

  `uvm_object_utils_begin(cnt_item)
    `uvm_field_int(reset, UVM_DEFAULT)
    `uvm_field_int(load, UVM_DEFAULT)
    `uvm_field_int(data_in, UVM_DEFAULT)
    `uvm_field_int(count, UVM_DEFAULT)
  `uvm_object_utils_end

  function new(string name = "cnt_item"); super.new(name); endfunction
endclass

// --- Driver ---
class cnt_driver extends uvm_driver #(cnt_item);
  `uvm_component_utils(cnt_driver)
  virtual cnt_if vif;

  function new(string n, uvm_component p); super.new(n, p); endfunction

  task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      @(posedge vif.clk);
      vif.reset   <= req.reset;
      vif.load    <= req.load;
      vif.data_in <= req.data_in;
      seq_item_port.item_done();
    end
  endtask
endclass

// --- Monitor ---
class cnt_monitor extends uvm_monitor;
  `uvm_component_utils(cnt_monitor)
  virtual cnt_if vif;
  uvm_analysis_port #(cnt_item) ap;

  function new(string n, uvm_component p); super.new(n, p); ap = new("ap", this); endfunction

  task run_phase(uvm_phase phase);
    forever begin
      cnt_item itm = cnt_item::type_id::create("itm");
      @(posedge vif.clk);
      #1; // Sample shortly after clock edge
      itm.reset   = vif.reset;
      itm.load    = vif.load;
      itm.data_in = vif.data_in;
      itm.count   = vif.count;
      ap.write(itm);
    end
  endtask
endclass

// --- Scoreboard (Minimalist) ---
class cnt_scb extends uvm_subscriber #(cnt_item);
  `uvm_component_utils(cnt_scb)
  bit [3:0] ref_count = 0;

  function new(string n, uvm_component p); super.new(n, p); endfunction

  function void write(cnt_item t);
    // Reference Model Logic
    if (t.reset) ref_count = 0;
    else if (t.load) ref_count = t.data_in;
    else ref_count++;

    // Compare after the next clock (delay logic or check current state)
    `uvm_info("SCB", $sformatf("Observed: %0d, Expected: %0d", t.count, ref_count), UVM_LOW)
  endfunction
endclass

// --- Agent & Env (Compact) ---
typedef uvm_sequencer #(cnt_item) cnt_seqr;

class cnt_env extends uvm_env;
  `uvm_component_utils(cnt_env)
  cnt_driver d; cnt_monitor m; cnt_seqr s; cnt_scb scb;

  function new(string n, uvm_component p); super.new(n, p); endfunction

  function void build_phase(uvm_phase phase);
    d = cnt_driver::type_id::create("d", this);
    m = cnt_monitor::type_id::create("m", this);
    s = cnt_seqr::type_id::create("s", this);
    scb = cnt_scb::type_id::create("scb", this);
    uvm_config_db#(virtual cnt_if)::get(this, "", "vif", d.vif);
    uvm_config_db#(virtual cnt_if)::get(this, "", "vif", m.vif);
  endfunction

  function void connect_phase(uvm_phase phase);
    d.seq_item_port.connect(s.seq_item_export);
    m.ap.connect(scb.analysis_export);
  endfunction
endclass

// --- Test (Using In-line Sequence to save space) ---
class cnt_test extends uvm_test;
  `uvm_component_utils(cnt_test)
  cnt_env env;

  function new(string n, uvm_component p); super.new(n, p); endfunction
  function void build_phase(uvm_phase phase); env = cnt_env::type_id::create("env", this); endfunction

  task run_phase(uvm_phase phase);
    cnt_item item = cnt_item::type_id::create("item");
    phase.raise_objection(this);
    
    // Reset Sequence
    item.randomize() with {reset == 1;}; env.s.execute_item(item);
    // Load Sequence
    item.randomize() with {reset == 0; load == 1; data_in == 4'hA;}; env.s.execute_item(item);
    // Counting Sequence
    repeat(10) begin
      item.randomize() with {reset == 0; load == 0;};
      env.s.execute_item(item);
    end
    
    #100;
    phase.drop_objection(this);
  endtask
endclass

// --- Top ---
module top;
  bit clk;
  always #5 clk = ~clk;
  cnt_if cif(clk);
  counter dut(clk, cif.reset, cif.load, cif.data_in, cif.count);

  initial begin
    uvm_config_db#(virtual cnt_if)::set(null, "uvm_test_top.env.*", "vif", cif);
    run_test("cnt_test");
  end
endmodule