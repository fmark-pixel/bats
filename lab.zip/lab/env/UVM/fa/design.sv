module full_adder(input a, b, cin, output sum, carry);
  assign sum = a ^ b ^ cin;
  assign carry = (a & b) | (b & cin) | (a & cin);
endmodule

interface fa_if;
  logic a, b, cin, sum, carry;
endinterface