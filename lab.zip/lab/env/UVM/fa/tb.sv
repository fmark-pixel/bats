`include "uvm_macros.svh"
import uvm_pkg::*;

// --- 1. Transaction (The Data) ---
class fa_item extends uvm_sequence_item;
  rand bit a, b, cin;
  bit sum, carry;
  `uvm_object_utils_begin(fa_item)
    `uvm_field_int(a, UVM_DEFAULT)
    `uvm_field_int(b, UVM_DEFAULT)
    `uvm_field_int(cin, UVM_DEFAULT)
  `uvm_object_utils_end
  function new(string n = ""); super.new(n); endfunction
endclass

// --- 2. Driver (The Signal Wiggler) ---
class fa_driver extends uvm_driver #(fa_item);
  `uvm_component_utils(fa_driver)
  virtual fa_if vif;
  function new(string n, uvm_component p); super.new(n, p); endfunction

  task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      {vif.a, vif.b, vif.cin} = {req.a, req.b, req.cin};
      #10; // Combinational delay
      seq_item_port.item_done();
    end
  endtask
endclass

// --- 3. Monitor (The Observer) ---
class fa_monitor extends uvm_monitor;
  `uvm_component_utils(fa_monitor)
  virtual fa_if vif;
  uvm_analysis_port #(fa_item) ap;
  function new(string n, uvm_component p); super.new(n, p); ap = new("ap", this); endfunction

  task run_phase(uvm_phase phase);
    fa_item itm = fa_item::type_id::create("itm");
    forever begin
      #10; // Sample after driver/DUT settle
      {itm.a, itm.b, itm.cin, itm.sum, itm.carry} = {vif.a, vif.b, vif.cin, vif.sum, vif.carry};
      ap.write(itm);
    end
  endtask
endclass

// --- 4. Scoreboard (The Auditor - Using Subscriber to save space) ---
class fa_scb extends uvm_subscriber #(fa_item);
  `uvm_component_utils(fa_scb)
  function new(string n, uvm_component p); super.new(n, p); endfunction

  function void write(fa_item t);
    bit exp_s = t.a ^ t.b ^ t.cin;
    bit exp_c = (t.a & t.b) | (t.b & t.cin) | (t.a & t.cin);
    if ({t.sum, t.carry} == {exp_s, exp_c})
      `uvm_info("PASS", $sformatf("In:%b%b%b Out:S%b C%b", t.a, t.b, t.cin, t.sum, t.carry), UVM_LOW)
    else `uvm_error("FAIL", "Result Mismatch!")
  endfunction
endclass

// --- 5. Env & Test (The House & The Script) ---
typedef uvm_sequencer #(fa_item) fa_seqr;

class fa_env extends uvm_env;
  `uvm_component_utils(fa_env)
  fa_driver d; fa_monitor m; fa_seqr s; fa_scb scb;
  function new(string n, uvm_component p); super.new(n, p); endfunction

  function void build_phase(uvm_phase phase);
    d = fa_driver::type_id::create("d", this);
    m = fa_monitor::type_id::create("m", this);
    s = fa_seqr::type_id::create("s", this);
    scb = fa_scb::type_id::create("scb", this);
    uvm_config_db#(virtual fa_if)::get(this, "", "vif", d.vif);
    uvm_config_db#(virtual fa_if)::get(this, "", "vif", m.vif);
  endfunction

  function void connect_phase(uvm_phase phase);
    d.seq_item_port.connect(s.seq_item_export);
    m.ap.connect(scb.analysis_export);
  endfunction
endclass

class test extends uvm_test;
  `uvm_component_utils(test)
  fa_env env;
  function new(string n, uvm_component p); super.new(n, p); endfunction
  function void build_phase(uvm_phase phase); env = fa_env::type_id::create("env", this); endfunction

  task run_phase(uvm_phase phase);
    fa_item item = fa_item::type_id::create("item");
    phase.raise_objection(this);
    repeat(8) begin // Test all 3-bit combinations
      void'(item.randomize());
      env.s.execute_item(item); // In-line stimulus
    end
    phase.drop_objection(this);
  endtask
endclass

// --- Top ---
module top;
  fa_if if_inst();
  full_adder dut(if_inst.a, if_inst.b, if_inst.cin, if_inst.sum, if_inst.carry);
  initial begin
    uvm_config_db#(virtual fa_if)::set(null, "*", "vif", if_inst);
    run_test("test");
  end
endmodule