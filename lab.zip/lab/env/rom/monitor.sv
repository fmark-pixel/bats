class monitor;
  virtual rom_if vif;
  mailbox mon2scb;
  transaction trans;

  function new(virtual rom_if vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction

  task main();
    forever begin
      @(posedge vif.clk);
      if (vif.en) begin

        trans.addr = vif.addr;
        trans.data = vif.data;
        
        mon2scb.put(trans);
        trans.display("MON");
      end
    end
  endtask
endclass