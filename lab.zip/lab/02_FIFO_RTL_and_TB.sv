//========================================
// SIMPLE FIFO RTL
//========================================
module fifo_8x8 (
  input clk, rst,
  input [7:0] din,
  input push, pop,
  output reg [7:0] dout,
  output reg full, empty
);
  
  reg [7:0] mem [7:0];
  reg [2:0] wr_ptr, rd_ptr;
  integer count;
  
  always @(posedge clk or posedge rst) begin
    if(rst) begin
      wr_ptr <= 0;
      rd_ptr <= 0;
      count <= 0;
      dout <= 0;
    end
    else begin
      if(push && !full) begin
        mem[wr_ptr] <= din;
        wr_ptr <= wr_ptr + 1;
        count <= count + 1;
      end
      
      if(pop && !empty) begin
        dout <= mem[rd_ptr];
        rd_ptr <= rd_ptr + 1;
        count <= count - 1;
      end
    end
  end
  
  always @(*) begin
    empty = (count == 0);
    full = (count == 8);
  end
  
endmodule

//========================================
// FIFO UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

// FIFO Transaction
class fifo_txn extends uvm_sequence_item;
  rand bit [7:0] data;
  rand bit push;
  rand bit pop;
  bit [7:0] read_data;
  
  `uvm_object_utils_begin(fifo_txn)
    `uvm_field_int(data, UVM_DEFAULT)
    `uvm_field_bit(push, UVM_DEFAULT)
    `uvm_field_bit(pop, UVM_DEFAULT)
    `uvm_field_int(read_data, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "fifo_txn");
    super.new(name);
  endfunction
endclass

// FIFO Sequence
class fifo_sequence extends uvm_sequence #(fifo_txn);
  `uvm_object_utils(fifo_sequence)
  
  function new(string name = "fifo_sequence");
    super.new(name);
  endfunction
  
  task body();
    fifo_txn txn;
    repeat(20) begin
      txn = fifo_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("FIFO_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// FIFO Driver
class fifo_driver extends uvm_driver #(fifo_txn);
  `uvm_component_utils(fifo_driver)
  virtual fifo_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual fifo_if)::get(this, "", "fifo_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fifo_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.din = txn.data;
      vif.push = txn.push;
      vif.pop = txn.pop;
      seq_item_port.item_done();
    end
  endtask
endclass

// FIFO Monitor
class fifo_monitor extends uvm_monitor;
  `uvm_component_utils(fifo_monitor)
  virtual fifo_if vif;
  uvm_analysis_port #(fifo_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual fifo_if)::get(this, "", "fifo_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fifo_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = fifo_txn::type_id::create("txn");
      txn.data = vif.din;
      txn.push = vif.push;
      txn.pop = vif.pop;
      txn.read_data = vif.dout;
      ap.write(txn);
    end
  endtask
endclass

// FIFO Scoreboard
class fifo_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(fifo_scoreboard)
  uvm_analysis_imp #(fifo_txn, fifo_scoreboard) ap_imp;
  bit [7:0] fifo_queue [$];
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(fifo_txn txn);
    if(txn.push && fifo_queue.size() < 8) begin
      fifo_queue.push_back(txn.data);
      `uvm_info("FIFO_SB", $sformatf("PUSH: data=%0d, queue_size=%0d", 
                                     txn.data, fifo_queue.size()), UVM_MEDIUM)
    end
    
    if(txn.pop && fifo_queue.size() > 0) begin
      bit [7:0] expected = fifo_queue.pop_front();
      if(expected === txn.read_data)
        `uvm_info("FIFO_SB", $sformatf("POP PASS: expected=%0d, got=%0d", 
                                       expected, txn.read_data), UVM_MEDIUM)
      else
        `uvm_error("FIFO_SB", $sformatf("POP FAIL: expected=%0d, got=%0d", 
                                        expected, txn.read_data))
    end
  endfunction
endclass

// FIFO Agent
class fifo_agent extends uvm_agent;
  `uvm_component_utils(fifo_agent)
  uvm_sequencer #(fifo_txn) sequencer;
  fifo_driver driver;
  fifo_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(fifo_txn)::type_id::create("sequencer", this);
    driver = fifo_driver::type_id::create("driver", this);
    monitor = fifo_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// FIFO Environment
class fifo_env extends uvm_env;
  `uvm_component_utils(fifo_env)
  fifo_agent agent;
  fifo_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = fifo_agent::type_id::create("agent", this);
    sb = fifo_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// FIFO Test
class fifo_test extends uvm_test;
  `uvm_component_utils(fifo_test)
  fifo_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = fifo_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fifo_sequence seq;
    phase.raise_objection(this);
    seq = fifo_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface fifo_if(input clk);
  logic rst;
  logic [7:0] din, dout;
  logic push, pop;
  logic full, empty;
endinterface

// Testbench
module tb_fifo;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  fifo_if fifo_if_inst(clk);
  
  fifo_8x8 dut(.clk(clk), .rst(rst), .din(fifo_if_inst.din), 
               .push(fifo_if_inst.push), .pop(fifo_if_inst.pop),
               .dout(fifo_if_inst.dout), .full(fifo_if_inst.full), 
               .empty(fifo_if_inst.empty));
  
  initial begin
    uvm_config_db#(virtual fifo_if)::set(null, "*", "fifo_if", fifo_if_inst);
    run_test("fifo_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
