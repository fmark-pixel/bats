//========================================
// SIMPLE FSM RTL (Traffic Light)
//========================================
module traffic_fsm (
  input clk, rst,
  input sensor,
  output reg red, yellow, green
);
  
  typedef enum {RED_STATE, GREEN_STATE, YELLOW_STATE} state_t;
  state_t current_state, next_state;
  
  // State transition logic
  always @(*) begin
    next_state = current_state;
    case(current_state)
      RED_STATE: 
        if(sensor) next_state = GREEN_STATE;
      
      GREEN_STATE:
        next_state = YELLOW_STATE;
      
      YELLOW_STATE:
        next_state = RED_STATE;
      
      default: next_state = RED_STATE;
    endcase
  end
  
  // State register
  always @(posedge clk or posedge rst) begin
    if(rst)
      current_state <= RED_STATE;
    else
      current_state <= next_state;
  end
  
  // Output logic
  always @(*) begin
    red = 0;
    green = 0;
    yellow = 0;
    
    case(current_state)
      RED_STATE: red = 1;
      GREEN_STATE: green = 1;
      YELLOW_STATE: yellow = 1;
    endcase
  end
  
endmodule

//========================================
// FSM UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

typedef enum {RED, GREEN, YELLOW} light_t;

// FSM Transaction
class fsm_txn extends uvm_sequence_item;
  rand bit sensor;
  light_t expected_light;
  light_t actual_light;
  
  `uvm_object_utils_begin(fsm_txn)
    `uvm_field_bit(sensor, UVM_DEFAULT)
    `uvm_field_enum(light_t, expected_light, UVM_DEFAULT)
    `uvm_field_enum(light_t, actual_light, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "fsm_txn");
    super.new(name);
  endfunction
endclass

// FSM Sequence
class fsm_sequence extends uvm_sequence #(fsm_txn);
  `uvm_object_utils(fsm_sequence)
  
  function new(string name = "fsm_sequence");
    super.new(name);
  endfunction
  
  task body();
    fsm_txn txn;
    repeat(10) begin
      txn = fsm_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("FSM_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// FSM Driver
class fsm_driver extends uvm_driver #(fsm_txn);
  `uvm_component_utils(fsm_driver)
  virtual fsm_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual fsm_if)::get(this, "", "fsm_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fsm_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.sensor = txn.sensor;
      seq_item_port.item_done();
    end
  endtask
endclass

// FSM Monitor
class fsm_monitor extends uvm_monitor;
  `uvm_component_utils(fsm_monitor)
  virtual fsm_if vif;
  uvm_analysis_port #(fsm_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual fsm_if)::get(this, "", "fsm_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fsm_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = fsm_txn::type_id::create("txn");
      txn.sensor = vif.sensor;
      
      // Determine actual light
      if(vif.red)
        txn.actual_light = RED;
      else if(vif.green)
        txn.actual_light = GREEN;
      else if(vif.yellow)
        txn.actual_light = YELLOW;
      
      ap.write(txn);
    end
  endtask
endclass

// FSM Scoreboard
class fsm_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(fsm_scoreboard)
  uvm_analysis_imp #(fsm_txn, fsm_scoreboard) ap_imp;
  light_t current_light = RED;
  bit prev_sensor = 0;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(fsm_txn txn);
    // FSM transitions
    case(current_light)
      RED:
        if(prev_sensor) 
          txn.expected_light = GREEN;
        else 
          txn.expected_light = RED;
      
      GREEN:
        txn.expected_light = YELLOW;
      
      YELLOW:
        txn.expected_light = RED;
    endcase
    
    // Check
    if(txn.expected_light === txn.actual_light)
      `uvm_info("FSM_SB", $sformatf("FSM PASS: %s -> %s", 
                                    current_light.name(), 
                                    txn.actual_light.name()), UVM_MEDIUM)
    else
      `uvm_error("FSM_SB", $sformatf("FSM FAIL: expected %s, got %s", 
                                     txn.expected_light.name(), 
                                     txn.actual_light.name()))
    
    current_light = txn.actual_light;
    prev_sensor = txn.sensor;
  endfunction
endclass

// FSM Agent
class fsm_agent extends uvm_agent;
  `uvm_component_utils(fsm_agent)
  uvm_sequencer #(fsm_txn) sequencer;
  fsm_driver driver;
  fsm_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(fsm_txn)::type_id::create("sequencer", this);
    driver = fsm_driver::type_id::create("driver", this);
    monitor = fsm_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// FSM Environment
class fsm_env extends uvm_env;
  `uvm_component_utils(fsm_env)
  fsm_agent agent;
  fsm_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = fsm_agent::type_id::create("agent", this);
    sb = fsm_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// FSM Test
class fsm_test extends uvm_test;
  `uvm_component_utils(fsm_test)
  fsm_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = fsm_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    fsm_sequence seq;
    phase.raise_objection(this);
    seq = fsm_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface fsm_if(input clk);
  logic rst;
  logic sensor;
  logic red, green, yellow;
endinterface

// Testbench
module tb_fsm;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  fsm_if fsm_if_inst(clk);
  
  traffic_fsm dut(.clk(clk), .rst(rst), .sensor(fsm_if_inst.sensor),
                  .red(fsm_if_inst.red), .green(fsm_if_inst.green),
                  .yellow(fsm_if_inst.yellow));
  
  initial begin
    uvm_config_db#(virtual fsm_if)::set(null, "*", "fsm_if", fsm_if_inst);
    run_test("fsm_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
