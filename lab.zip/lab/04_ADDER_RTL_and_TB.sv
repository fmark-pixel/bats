//========================================
// SIMPLE ADDER RTL (8-bit)
//========================================
module adder_8bit (
  input clk, rst,
  input [7:0] a, b,
  input valid_in,
  output reg [8:0] sum,
  output reg valid_out
);
  
  always @(posedge clk or posedge rst) begin
    if(rst) begin
      sum <= 9'b0;
      valid_out <= 0;
    end
    else begin
      if(valid_in) begin
        sum <= a + b;
        valid_out <= 1;
      end
      else begin
        valid_out <= 0;
      end
    end
  end
  
endmodule

//========================================
// ADDER UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

// Adder Transaction
class adder_txn extends uvm_sequence_item;
  rand bit [7:0] a, b;
  rand bit valid_in;
  bit [8:0] sum;
  bit valid_out;
  
  `uvm_object_utils_begin(adder_txn)
    `uvm_field_int(a, UVM_DEFAULT)
    `uvm_field_int(b, UVM_DEFAULT)
    `uvm_field_bit(valid_in, UVM_DEFAULT)
    `uvm_field_int(sum, UVM_DEFAULT)
    `uvm_field_bit(valid_out, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "adder_txn");
    super.new(name);
  endfunction
endclass

// Adder Sequence
class adder_sequence extends uvm_sequence #(adder_txn);
  `uvm_object_utils(adder_sequence)
  
  function new(string name = "adder_sequence");
    super.new(name);
  endfunction
  
  task body();
    adder_txn txn;
    repeat(12) begin
      txn = adder_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("ADD_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// Adder Driver
class adder_driver extends uvm_driver #(adder_txn);
  `uvm_component_utils(adder_driver)
  virtual adder_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual adder_if)::get(this, "", "adder_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    adder_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.a = txn.a;
      vif.b = txn.b;
      vif.valid_in = txn.valid_in;
      seq_item_port.item_done();
    end
  endtask
endclass

// Adder Monitor
class adder_monitor extends uvm_monitor;
  `uvm_component_utils(adder_monitor)
  virtual adder_if vif;
  uvm_analysis_port #(adder_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual adder_if)::get(this, "", "adder_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    adder_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = adder_txn::type_id::create("txn");
      txn.a = vif.a;
      txn.b = vif.b;
      txn.valid_in = vif.valid_in;
      txn.sum = vif.sum;
      txn.valid_out = vif.valid_out;
      ap.write(txn);
    end
  endtask
endclass

// Adder Scoreboard
class adder_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(adder_scoreboard)
  uvm_analysis_imp #(adder_txn, adder_scoreboard) ap_imp;
  bit [7:0] prev_a, prev_b;
  bit prev_valid;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
  endfunction
  
  function void write(adder_txn txn);
    if(prev_valid) begin
      bit [8:0] expected = prev_a + prev_b;
      if(expected === txn.sum)
        `uvm_info("ADD_SB", $sformatf("PASS: %0d + %0d = %0d (got %0d)", 
                                      prev_a, prev_b, expected, txn.sum), UVM_MEDIUM)
      else
        `uvm_error("ADD_SB", $sformatf("FAIL: %0d + %0d = expected %0d, got %0d", 
                                       prev_a, prev_b, expected, txn.sum))
    end
    
    prev_a = txn.a;
    prev_b = txn.b;
    prev_valid = txn.valid_in;
  endfunction
endclass

// Adder Agent
class adder_agent extends uvm_agent;
  `uvm_component_utils(adder_agent)
  uvm_sequencer #(adder_txn) sequencer;
  adder_driver driver;
  adder_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(adder_txn)::type_id::create("sequencer", this);
    driver = adder_driver::type_id::create("driver", this);
    monitor = adder_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// Adder Environment
class adder_env extends uvm_env;
  `uvm_component_utils(adder_env)
  adder_agent agent;
  adder_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = adder_agent::type_id::create("agent", this);
    sb = adder_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// Adder Test
class adder_test extends uvm_test;
  `uvm_component_utils(adder_test)
  adder_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = adder_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    adder_sequence seq;
    phase.raise_objection(this);
    seq = adder_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface adder_if(input clk);
  logic rst;
  logic [7:0] a, b;
  logic valid_in;
  logic [8:0] sum;
  logic valid_out;
endinterface

// Testbench
module tb_adder;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  adder_if adder_if_inst(clk);
  
  adder_8bit dut(.clk(clk), .rst(rst), .a(adder_if_inst.a), .b(adder_if_inst.b),
                 .valid_in(adder_if_inst.valid_in), .sum(adder_if_inst.sum),
                 .valid_out(adder_if_inst.valid_out));
  
  initial begin
    uvm_config_db#(virtual adder_if)::set(null, "*", "adder_if", adder_if_inst);
    run_test("adder_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
