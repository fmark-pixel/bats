//========================================
// SIMPLE RAM RTL (4x8 bit)
//========================================
module ram_4x8 (
  input clk, rst,
  input [1:0] addr,
  input [7:0] din,
  input we,
  output reg [7:0] dout
);
  
  reg [7:0] mem [3:0];
  
  always @(posedge clk or posedge rst) begin
    if(rst) begin
      dout <= 8'b0;
      mem[0] <= 8'b0;
      mem[1] <= 8'b0;
      mem[2] <= 8'b0;
      mem[3] <= 8'b0;
    end
    else begin
      if(we) begin
        mem[addr] <= din;
      end
      dout <= mem[addr];
    end
  end
  
endmodule

//========================================
// RAM UVM TESTBENCH
//========================================
`include "uvm_macros.svh"
import uvm_pkg::*;

// RAM Transaction
class ram_txn extends uvm_sequence_item;
  rand bit [1:0] addr;
  rand bit [7:0] din;
  rand bit we;
  bit [7:0] dout;
  
  `uvm_object_utils_begin(ram_txn)
    `uvm_field_int(addr, UVM_DEFAULT)
    `uvm_field_int(din, UVM_DEFAULT)
    `uvm_field_bit(we, UVM_DEFAULT)
    `uvm_field_int(dout, UVM_DEFAULT)
  `uvm_object_utils_end
  
  function new(string name = "ram_txn");
    super.new(name);
  endfunction
endclass

// RAM Sequence
class ram_sequence extends uvm_sequence #(ram_txn);
  `uvm_object_utils(ram_sequence)
  
  function new(string name = "ram_sequence");
    super.new(name);
  endfunction
  
  task body();
    ram_txn txn;
    repeat(16) begin
      txn = ram_txn::type_id::create("txn");
      start_item(txn);
      if(!txn.randomize())
        `uvm_error("RAM_SEQ", "Randomization failed");
      finish_item(txn);
    end
  endtask
endclass

// RAM Driver
class ram_driver extends uvm_driver #(ram_txn);
  `uvm_component_utils(ram_driver)
  virtual ram_if vif;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual ram_if)::get(this, "", "ram_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    ram_txn txn;
    forever begin
      seq_item_port.get_next_item(txn);
      @(posedge vif.clk);
      vif.addr = txn.addr;
      vif.din = txn.din;
      vif.we = txn.we;
      seq_item_port.item_done();
    end
  endtask
endclass

// RAM Monitor
class ram_monitor extends uvm_monitor;
  `uvm_component_utils(ram_monitor)
  virtual ram_if vif;
  uvm_analysis_port #(ram_txn) ap;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual ram_if)::get(this, "", "ram_if", vif))
      `uvm_fatal("NOVIF", "No virtual interface");
  endfunction
  
  task run_phase(uvm_run_phase phase);
    ram_txn txn;
    forever begin
      @(posedge vif.clk);
      txn = ram_txn::type_id::create("txn");
      txn.addr = vif.addr;
      txn.din = vif.din;
      txn.we = vif.we;
      txn.dout = vif.dout;
      ap.write(txn);
    end
  endtask
endclass

// RAM Scoreboard
class ram_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(ram_scoreboard)
  uvm_analysis_imp #(ram_txn, ram_scoreboard) ap_imp;
  bit [7:0] memory [bit [1:0]];
  bit [1:0] prev_addr;
  bit prev_we;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap_imp = new("ap_imp", this);
    // Initialize memory
    foreach(memory[i])
      memory[i] = 8'b0;
  endfunction
  
  function void write(ram_txn txn);
    // Check previous read data
    if(!prev_we && prev_addr >= 0 && prev_addr <= 3) begin
      if(memory[prev_addr] === txn.dout)
        `uvm_info("RAM_SB", $sformatf("READ PASS: addr=%0d, expected=%0d, got=%0d", 
                                      prev_addr, memory[prev_addr], txn.dout), UVM_MEDIUM)
      else
        `uvm_error("RAM_SB", $sformatf("READ FAIL: addr=%0d, expected=%0d, got=%0d", 
                                       prev_addr, memory[prev_addr], txn.dout))
    end
    
    // Update write
    if(txn.we) begin
      memory[txn.addr] = txn.din;
      `uvm_info("RAM_SB", $sformatf("WRITE: addr=%0d, data=%0d", txn.addr, txn.din), UVM_MEDIUM)
    end
    
    prev_addr = txn.addr;
    prev_we = txn.we;
  endfunction
endclass

// RAM Agent
class ram_agent extends uvm_agent;
  `uvm_component_utils(ram_agent)
  uvm_sequencer #(ram_txn) sequencer;
  ram_driver driver;
  ram_monitor monitor;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    sequencer = uvm_sequencer#(ram_txn)::type_id::create("sequencer", this);
    driver = ram_driver::type_id::create("driver", this);
    monitor = ram_monitor::type_id::create("monitor", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    driver.seq_item_port.connect(sequencer.seq_item_export);
  endfunction
endclass

// RAM Environment
class ram_env extends uvm_env;
  `uvm_component_utils(ram_env)
  ram_agent agent;
  ram_scoreboard sb;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    agent = ram_agent::type_id::create("agent", this);
    sb = ram_scoreboard::type_id::create("sb", this);
  endfunction
  
  function void connect_phase(uvm_connect_phase phase);
    super.connect_phase(phase);
    agent.monitor.ap.connect(sb.ap_imp);
  endfunction
endclass

// RAM Test
class ram_test extends uvm_test;
  `uvm_component_utils(ram_test)
  ram_env env;
  
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  
  function void build_phase(uvm_build_phase phase);
    super.build_phase(phase);
    env = ram_env::type_id::create("env", this);
  endfunction
  
  task run_phase(uvm_run_phase phase);
    ram_sequence seq;
    phase.raise_objection(this);
    seq = ram_sequence::type_id::create("seq");
    seq.start(env.agent.sequencer);
    phase.drop_objection(this);
  endtask
endclass

// Interface
interface ram_if(input clk);
  logic rst;
  logic [1:0] addr;
  logic [7:0] din;
  logic we;
  logic [7:0] dout;
endinterface

// Testbench
module tb_ram;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  
  bit clk, rst;
  ram_if ram_if_inst(clk);
  
  ram_4x8 dut(.clk(clk), .rst(rst), .addr(ram_if_inst.addr),
              .din(ram_if_inst.din), .we(ram_if_inst.we),
              .dout(ram_if_inst.dout));
  
  initial begin
    uvm_config_db#(virtual ram_if)::set(null, "*", "ram_if", ram_if_inst);
    run_test("ram_test");
  end
  
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end
  
  initial begin
    rst = 1;
    #20 rst = 0;
  end
endmodule
