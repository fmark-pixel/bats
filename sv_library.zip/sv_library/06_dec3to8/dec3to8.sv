// =============================================================================
// Module  : dec3to8
// Description : 3-to-8 Binary Decoder
//               out[i] is asserted when addr == i AND en is high.
//               Active-high enable (en). Active-high outputs.
// Synthesisable : YES
// =============================================================================
module dec3to8 (
    input  logic [2:0] addr,
    input  logic       en,
    output logic [7:0] out
);
    always_comb begin
        out = 8'b0;
        if (en)
            out = 8'b1 << addr;  // one-hot: only out[addr] = 1
    end

endmodule
