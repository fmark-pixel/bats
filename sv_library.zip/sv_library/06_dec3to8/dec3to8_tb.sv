// =============================================================================
// Testbench : dec3to8_tb
// =============================================================================
`timescale 1ns/1ps

module dec3to8_tb;

    logic [2:0] addr;
    logic       en;
    logic [7:0] out;

    dec3to8 dut (.*);

    int pass_cnt=0, fail_cnt=0;

    task automatic check(input logic [2:0] ta, input logic te);
        logic [7:0] exp;
        addr = ta; en = te; #10;
        exp = te ? (8'b1 << ta) : 8'h00;
        if (out === exp) pass_cnt++;
        else begin
            $error("FAIL | addr=%0d en=%0b | got=%08b exp=%08b",
                    ta, te, out, exp);
            fail_cnt++;
        end
    endtask

    initial begin
        $display("===== 3-to-8 Decoder Testbench =====");

        // en=0: all outputs must be 0
        for (int i = 0; i < 8; i++) check(i[2:0], 1'b0);

        // en=1: one-hot for each address
        for (int i = 0; i < 8; i++) check(i[2:0], 1'b1);

        $display("Pass: %0d  Fail: %0d", pass_cnt, fail_cnt);
        $display("===== Test Complete =====");
        $finish;
    end

endmodule
