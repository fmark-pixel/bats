// =============================================================================
// Module  : demux1to4
// Description : 1-to-4 Demultiplexer
//               Routes single input 'in' to one of 4 outputs based on 'sel'.
//               All other outputs are driven LOW.
//               en (active-high enable): when deasserted, all outputs = 0.
// Synthesisable : YES
// =============================================================================
module demux1to4 (
    input  logic       in,
    input  logic [1:0] sel,
    input  logic       en,    // active-high enable
    output logic [3:0] out
);
    always_comb begin
        out = 4'b0000; // default: all outputs low
        if (en) begin
            out[sel] = in;
        end
    end

endmodule
