// =============================================================================
// Testbench : demux1to4_tb
// =============================================================================
`timescale 1ns/1ps

module demux1to4_tb;

    logic       in;
    logic [1:0] sel;
    logic       en;
    logic [3:0] out;

    demux1to4 dut (.*);

    int pass_cnt=0, fail_cnt=0;

    task automatic check(input logic tin, logic [1:0] tsel, logic ten);
        logic [3:0] exp;
        in = tin; sel = tsel; en = ten;
        #10;
        exp = 4'b0;
        if (ten) exp[tsel] = tin;
        if (out === exp) pass_cnt++;
        else begin
            $error("FAIL | in=%0b sel=%0d en=%0b | got=%04b exp=%04b",
                    tin, tsel, ten, out, exp);
            fail_cnt++;
        end
    endtask

    initial begin
        $display("===== 1:4 DEMUX Testbench =====");

        // en=0: all outputs must be 0 regardless of in/sel
        for (int i = 0; i < 4; i++) check(1'b0, i[1:0], 1'b0);
        for (int i = 0; i < 4; i++) check(1'b1, i[1:0], 1'b0);

        // en=1, in=0: selected output = 0, rest = 0
        for (int i = 0; i < 4; i++) check(1'b0, i[1:0], 1'b1);

        // en=1, in=1: selected output = 1, rest = 0
        for (int i = 0; i < 4; i++) check(1'b1, i[1:0], 1'b1);

        $display("Pass: %0d  Fail: %0d", pass_cnt, fail_cnt);
        $display("===== Test Complete =====");
        $finish;
    end

endmodule
