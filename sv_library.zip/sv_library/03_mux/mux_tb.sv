// =============================================================================
// Testbench : mux_tb
// Tests mux4to1 and mux8to1 exhaustively
// =============================================================================
`timescale 1ns/1ps

module mux_tb;

    // ---- 4:1 MUX signals ----
    logic [3:0] d4;
    logic [1:0] sel4;
    logic       out4;

    // ---- 8:1 MUX signals ----
    logic [7:0] d8;
    logic [2:0] sel8;
    logic       out8;

    mux4to1 dut4 (.d(d4), .sel(sel4), .out(out4));
    mux8to1 dut8 (.d(d8), .sel(sel8), .out(out8));

    int pass4=0, fail4=0, pass8=0, fail8=0;

    // ---- 4:1 MUX exhaustive test ----
    // 4 data bits × 4 select combos = 16 input combos
    initial begin
        $display("===== 4:1 MUX Test =====");
        for (int dv = 0; dv < 16; dv++) begin
            d4 = dv[3:0];
            for (int sv = 0; sv < 4; sv++) begin
                sel4 = sv[1:0];
                #5;
                if (out4 === d4[sel4]) begin
                    pass4++;
                end else begin
                    $error("4:1 FAIL | d=%04b sel=%0d | got=%0b exp=%0b",
                            d4, sel4, out4, d4[sel4]);
                    fail4++;
                end
            end
        end
        $display("4:1 MUX – Pass: %0d  Fail: %0d", pass4, fail4);
    end

    // ---- 8:1 MUX exhaustive test ----
    initial begin
        #500; // run after 4:1 test completes
        $display("===== 8:1 MUX Test =====");
        for (int dv = 0; dv < 256; dv++) begin
            d8 = dv[7:0];
            for (int sv = 0; sv < 8; sv++) begin
                sel8 = sv[2:0];
                #5;
                if (out8 === d8[sel8]) begin
                    pass8++;
                end else begin
                    $error("8:1 FAIL | d=%08b sel=%0d | got=%0b exp=%0b",
                            d8, sel8, out8, d8[sel8]);
                    fail8++;
                end
            end
        end
        $display("8:1 MUX – Pass: %0d  Fail: %0d", pass8, fail8);
        $display("===== Test Complete =====");
        $finish;
    end

endmodule
