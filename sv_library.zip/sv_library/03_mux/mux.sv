// =============================================================================
// Module  : mux4to1
// Description : 4-to-1 Multiplexer (1-bit data lines)
//               out = d[sel]
// Synthesisable : YES
// =============================================================================
module mux4to1 (
    input  logic [3:0] d,    // data inputs  d[0]..d[3]
    input  logic [1:0] sel,  // select lines
    output logic       out
);
    assign out = d[sel];

endmodule


// =============================================================================
// Module  : mux8to1
// Description : 8-to-1 Multiplexer (1-bit data lines)
//               Internally built from two mux4to1 + one mux2to1 stage.
// Synthesisable : YES
// =============================================================================
module mux8to1 (
    input  logic [7:0] d,    // data inputs  d[0]..d[7]
    input  logic [2:0] sel,  // select lines
    output logic       out
);
    logic out_lo, out_hi;

    // Lower half: sel[2]=0 → picks among d[0..3]
    mux4to1 lo_mux (.d(d[3:0]), .sel(sel[1:0]), .out(out_lo));
    // Upper half: sel[2]=1 → picks among d[4..7]
    mux4to1 hi_mux (.d(d[7:4]), .sel(sel[1:0]), .out(out_hi));

    // Final stage: sel[2] chooses between halves
    assign out = sel[2] ? out_hi : out_lo;

endmodule
