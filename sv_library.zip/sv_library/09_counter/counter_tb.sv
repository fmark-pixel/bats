// =============================================================================
// Testbench : counter_tb
// Tests updown_counter (4-bit) and mod_n_counter (MOD=10, MOD=6)
// =============================================================================
`timescale 1ns/1ps

module counter_tb;

    logic clk = 0;
    always #5 clk = ~clk;

    // ---- Up/Down Counter ----
    logic       ud_rst, ud_en, ud_dir, ud_load;
    logic [3:0] ud_din, ud_cnt;
    logic       ud_tc;

    updown_counter #(4) u_ud (
        .clk, .rst(ud_rst), .en(ud_en), .dir(ud_dir),
        .load(ud_load), .din(ud_din), .cnt(ud_cnt), .tc(ud_tc)
    );

    // ---- Mod-10 Counter ----
    logic       m10_rst, m10_en;
    logic [3:0] m10_cnt;
    logic       m10_tc;

    mod_n_counter #(.MOD(10), .WIDTH(4)) u_m10 (
        .clk, .rst(m10_rst), .en(m10_en), .cnt(m10_cnt), .tc(m10_tc)
    );

    // ---- Mod-6 Counter ----
    logic       m6_rst, m6_en;
    logic [2:0] m6_cnt;
    logic       m6_tc;

    mod_n_counter #(.MOD(6), .WIDTH(3)) u_m6 (
        .clk, .rst(m6_rst), .en(m6_en), .cnt(m6_cnt), .tc(m6_tc)
    );

    task tick(); @(posedge clk); #1; endtask

    // ---- Up Counter Test ----
    task test_up_counter;
        $display("\n--- Up Counter Test (0..15 then wrap) ---");
        ud_rst=1; ud_en=1; ud_dir=1; ud_load=0; ud_din=4'h0; tick();
        ud_rst=0;
        for (int i = 0; i <= 16; i++) begin
            $display("  cnt=%0d tc=%0b", ud_cnt, ud_tc);
            tick();
        end
        $display("Up Counter: final cnt=%0d (expected 1 after 17 ticks from 0)", ud_cnt);
    endtask

    // ---- Down Counter Test ----
    task test_down_counter;
        $display("\n--- Down Counter Test (load 8, count down) ---");
        ud_load=1; ud_din=4'd8; ud_dir=0; tick();
        ud_load=0;
        for (int i = 0; i <= 9; i++) begin
            $display("  cnt=%0d tc=%0b", ud_cnt, ud_tc);
            tick();
        end
    endtask

    // ---- Parallel Load Test ----
    task test_load;
        $display("\n--- Parallel Load Test ---");
        ud_load=1; ud_din=4'hA; ud_dir=1; tick();
        #1;
        assert(ud_cnt === 4'hA) $display("Load PASS: cnt=0x%h", ud_cnt);
        else $error("Load FAIL: cnt=0x%h exp=0xA", ud_cnt);
        ud_load=0;
    endtask

    // ---- Mod-10 Counter Test ----
    task test_mod10;
        int tc_count = 0;
        $display("\n--- Mod-10 Counter Test (40 ticks = 4 full cycles) ---");
        m10_rst=1; m10_en=1; tick(); m10_rst=0;
        for (int i = 0; i < 40; i++) begin
            if (m10_tc) tc_count++;
            $display("  cnt=%0d tc=%0b", m10_cnt, m10_tc);
            tick();
        end
        $display("Mod-10: tc_count=%0d (expected 4 over 40 ticks)", tc_count);
        assert(tc_count == 4) else $error("Mod-10 FAIL: tc_count=%0d", tc_count);
    endtask

    // ---- Mod-6 Counter Test ----
    task test_mod6;
        $display("\n--- Mod-6 Counter Test (12 ticks = 2 full cycles) ---");
        m6_rst=1; m6_en=1; tick(); m6_rst=0;
        for (int i = 0; i < 13; i++) begin
            $display("  cnt=%0d tc=%0b", m6_cnt, m6_tc);
            assert(m6_cnt < 3'd6) else $error("Mod-6 FAIL: cnt=%0d exceeded 5", m6_cnt);
            tick();
        end
        $display("Mod-6 Test PASSED");
    endtask

    initial begin
        test_up_counter;
        test_down_counter;
        test_load;
        test_mod10;
        test_mod6;
        $display("\n===== All Counter Tests Complete =====");
        $finish;
    end

endmodule
