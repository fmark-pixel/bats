// =============================================================================
// Module  : updown_counter
// Description : Parameterised N-bit Up/Down Counter
//               dir=1 → count up; dir=0 → count down.
//               load=1 → synchronous parallel load.
//               Synchronous active-high reset.
// Synthesisable : YES
// =============================================================================
module updown_counter #(
    parameter int WIDTH = 4
)(
    input  logic             clk,
    input  logic             rst,
    input  logic             en,
    input  logic             dir,    // 1=up, 0=down
    input  logic             load,
    input  logic [WIDTH-1:0] din,
    output logic [WIDTH-1:0] cnt,
    output logic             tc      // terminal count (overflow/underflow flag)
);
    always_ff @(posedge clk) begin
        if (rst) begin
            cnt <= '0;
        end else if (en) begin
            if (load)
                cnt <= din;
            else if (dir)
                cnt <= cnt + 1'b1;   // count up
            else
                cnt <= cnt - 1'b1;   // count down
        end
    end

    // Terminal count: up → all 1s, down → all 0s
    assign tc = dir ? (&cnt) : (~|cnt);

endmodule


// =============================================================================
// Module  : mod_n_counter
// Description : Modulo-N Counter (counts 0 to MOD-1, then wraps to 0)
//               N is set via parameter MOD.
//               tc pulses high for one cycle when counter wraps.
//               WIDTH is automatically sized to hold MOD-1.
// Synthesisable : YES
// =============================================================================
module mod_n_counter #(
    parameter int MOD   = 10,
    parameter int WIDTH = $clog2(MOD)
)(
    input  logic             clk,
    input  logic             rst,
    input  logic             en,
    output logic [WIDTH-1:0] cnt,
    output logic             tc    // one-cycle pulse at wrap (cnt == MOD-1)
);
    assign tc = (cnt == WIDTH'(MOD - 1)) && en;

    always_ff @(posedge clk) begin
        if (rst)
            cnt <= '0;
        else if (en) begin
            if (cnt == WIDTH'(MOD - 1))
                cnt <= '0;          // wrap to 0
            else
                cnt <= cnt + 1'b1;
        end
    end

endmodule
