// =============================================================================
// Module  : rca_4bit
// Description : 4-bit Ripple Carry Adder built from four full_adder instances.
//               Carry propagates from LSB to MSB (ripple).
//               cout is the carry out of bit 3 (overflow indicator).
// Synthesisable : YES
// =============================================================================
module rca_4bit (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       cin,
    output logic [3:0] sum,
    output logic       cout
);

    logic [3:0] carry; // carry[0] = first internal carry, carry[3] = final carry out

    // Bit 0 – uses external cin
    full_adder fa0 (.a(a[0]), .b(b[0]), .cin(cin),      .sum(sum[0]), .cout(carry[0]));
    // Bit 1
    full_adder fa1 (.a(a[1]), .b(b[1]), .cin(carry[0]), .sum(sum[1]), .cout(carry[1]));
    // Bit 2
    full_adder fa2 (.a(a[2]), .b(b[2]), .cin(carry[1]), .sum(sum[2]), .cout(carry[2]));
    // Bit 3 – MSB
    full_adder fa3 (.a(a[3]), .b(b[3]), .cin(carry[2]), .sum(sum[3]), .cout(cout));

endmodule
