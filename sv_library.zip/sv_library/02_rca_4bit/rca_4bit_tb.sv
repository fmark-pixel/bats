// =============================================================================
// Testbench : rca_4bit_tb
// Strategy  : Directed corner cases + random stimulus
// =============================================================================
`timescale 1ns/1ps

module rca_4bit_tb;

    logic [3:0] a, b;
    logic       cin;
    logic [3:0] sum;
    logic       cout;

    // Reference model output
    logic [4:0] expected;

    rca_4bit dut (.*);

    int pass_cnt = 0, fail_cnt = 0;

    task automatic check(input logic [3:0] ta, tb, input logic tc);
        a = ta; b = tb; cin = tc;
        #10;
        expected = {1'b0, ta} + {1'b0, tb} + tc;
        if ({cout, sum} === expected) begin
            pass_cnt++;
        end else begin
            $error("FAIL | a=%0d b=%0d cin=%0b | got {cout,sum}=%0b%04b | exp=%05b",
                    ta, tb, tc, cout, sum, expected);
            fail_cnt++;
        end
    endtask

    initial begin
        $display("====== 4-bit RCA Testbench ======");

        // --- Directed tests ---
        check(4'd0,  4'd0,  1'b0);  // 0+0
        check(4'd0,  4'd0,  1'b1);  // 0+0+1
        check(4'hF,  4'h0,  1'b0);  // max A
        check(4'h0,  4'hF,  1'b0);  // max B
        check(4'hF,  4'hF,  1'b0);  // max both – should overflow
        check(4'hF,  4'hF,  1'b1);  // max + carry in
        check(4'h5,  4'h3,  1'b0);  // 5+3=8
        check(4'hA,  4'h5,  1'b1);  // 10+5+1=16, cout=1 sum=0

        // --- Random stimulus (50 vectors) ---
        repeat(50) begin
            check($urandom_range(0,15), $urandom_range(0,15), $urandom_range(0,1));
        end

        $display("Pass: %0d  Fail: %0d", pass_cnt, fail_cnt);
        $display("====== Test Complete ======");
        $finish;
    end

endmodule
