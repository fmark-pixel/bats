// =============================================================================
// Module  : full_adder
// Description : 1-bit Full Adder
//               sum  = a ^ b ^ cin
//               cout = majority(a, b, cin)
// Synthesisable : YES
// =============================================================================
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    assign sum  = a ^ b ^ cin;
    assign cout = (a & b) | (b & cin) | (a & cin);

endmodule
