// =============================================================================
// Testbench : full_adder_tb
// Tests all 8 input combinations exhaustively
// =============================================================================
`timescale 1ns/1ps

module full_adder_tb;

    logic a, b, cin;
    logic sum, cout;

    // Expected outputs (computed independently)
    logic exp_sum, exp_cout;

    // Instantiate DUT
    full_adder dut (.*);

    // Test task
    task automatic apply_and_check(input logic ta, tb, tc);
        a = ta; b = tb; cin = tc;
        #10;
        exp_sum  = ta ^ tb ^ tc;
        exp_cout = (ta & tb) | (tb & tc) | (ta & tc);
        assert (sum == exp_sum && cout == exp_cout)
            $display("PASS | a=%0b b=%0b cin=%0b | sum=%0b cout=%0b",
                      ta, tb, tc, sum, cout);
        else
            $error("FAIL | a=%0b b=%0b cin=%0b | got sum=%0b cout=%0b | exp sum=%0b cout=%0b",
                    ta, tb, tc, sum, cout, exp_sum, exp_cout);
    endtask

    initial begin
        $display("====== Full Adder Testbench ======");
        // Exhaustive test of all 2^3 = 8 input combinations
        for (int i = 0; i < 8; i++) begin
            apply_and_check(i[2], i[1], i[0]);
        end
        $display("====== Test Complete ======");
        $finish;
    end

endmodule
