// =============================================================================
// Module  : dff
// Description : D Flip-Flop with synchronous active-high reset and enable.
//               Q captures D on rising clock edge when en=1.
//               reset overrides en (synchronous reset takes priority).
// Synthesisable : YES
// =============================================================================
module dff (
    input  logic clk,
    input  logic rst,    // synchronous active-high reset
    input  logic en,     // clock enable
    input  logic d,
    output logic q,
    output logic q_n     // complementary output
);
    always_ff @(posedge clk) begin
        if (rst)
            q <= 1'b0;
        else if (en)
            q <= d;
        // else: hold
    end

    assign q_n = ~q;

endmodule


// =============================================================================
// Module  : tff
// Description : T (Toggle) Flip-Flop with synchronous reset and enable.
//               When T=1 and en=1: Q toggles.
//               When T=0 and en=1: Q holds.
//               Implemented from D-FF: D = T ^ Q.
// Synthesisable : YES
// =============================================================================
module tff (
    input  logic clk,
    input  logic rst,
    input  logic en,
    input  logic t,
    output logic q,
    output logic q_n
);
    always_ff @(posedge clk) begin
        if (rst)
            q <= 1'b0;
        else if (en)
            q <= t ^ q;  // T flip-flop characteristic equation
    end

    assign q_n = ~q;

endmodule


// =============================================================================
// Module  : jkff
// Description : JK Flip-Flop with synchronous reset and enable.
//               Truth table (when en=1):
//               J=0, K=0 → Q holds
//               J=0, K=1 → Q = 0  (Reset)
//               J=1, K=0 → Q = 1  (Set)
//               J=1, K=1 → Q = ~Q (Toggle)
//               Implemented using: D = J~Q + ~KQ
// Synthesisable : YES
// =============================================================================
module jkff (
    input  logic clk,
    input  logic rst,
    input  logic en,
    input  logic j,
    input  logic k,
    output logic q,
    output logic q_n
);
    always_ff @(posedge clk) begin
        if (rst)
            q <= 1'b0;
        else if (en) begin
            case ({j, k})
                2'b00: q <= q;       // Hold
                2'b01: q <= 1'b0;    // Reset
                2'b10: q <= 1'b1;    // Set
                2'b11: q <= ~q;      // Toggle
            endcase
        end
    end

    assign q_n = ~q;

endmodule
