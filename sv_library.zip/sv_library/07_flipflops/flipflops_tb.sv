// =============================================================================
// Testbench : flipflops_tb
// Tests DFF, TFF, JKFF with directed vectors
// =============================================================================
`timescale 1ns/1ps

module flipflops_tb;

    // Common signals
    logic clk = 0;
    always #5 clk = ~clk;  // 100 MHz

    // ===================== D Flip-Flop =====================
    logic dff_rst, dff_en, dff_d, dff_q, dff_qn;
    dff u_dff (.clk, .rst(dff_rst), .en(dff_en),
               .d(dff_d), .q(dff_q), .q_n(dff_qn));

    // ===================== T Flip-Flop =====================
    logic tff_rst, tff_en, tff_t, tff_q, tff_qn;
    tff u_tff (.clk, .rst(tff_rst), .en(tff_en),
               .t(tff_t), .q(tff_q), .q_n(tff_qn));

    // ===================== JK Flip-Flop =====================
    logic jkff_rst, jkff_en, jkff_j, jkff_k, jkff_q, jkff_qn;
    jkff u_jkff (.clk, .rst(jkff_rst), .en(jkff_en),
                 .j(jkff_j), .k(jkff_k), .q(jkff_q), .q_n(jkff_qn));

    // Helper task: apply input, wait for clock, check output
    task automatic tick();
        @(posedge clk); #1; // capture 1ns after posedge
    endtask

    // ---- DFF Tests ----
    task test_dff;
        $display("\n--- D Flip-Flop Tests ---");
        dff_rst=1; dff_en=0; dff_d=0; tick();
        assert(dff_q===0) else $error("DFF reset fail");

        // Enable=0: should hold Q even if D changes
        dff_rst=0; dff_en=0; dff_d=1; tick();
        assert(dff_q===0) else $error("DFF hold fail");

        // Enable=1: Q captures D
        dff_en=1; dff_d=1; tick();
        assert(dff_q===1) else $error("DFF capture 1 fail");
        assert(dff_qn===0) else $error("DFF qn fail");

        dff_d=0; tick();
        assert(dff_q===0) else $error("DFF capture 0 fail");

        // Synchronous reset overrides en
        dff_d=1; dff_rst=1; tick();
        assert(dff_q===0) else $error("DFF sync reset fail");

        $display("DFF Tests PASSED");
    endtask

    // ---- TFF Tests ----
    task test_tff;
        $display("\n--- T Flip-Flop Tests ---");
        tff_rst=1; tff_en=1; tff_t=1; tick();
        assert(tff_q===0) else $error("TFF reset fail");

        tff_rst=0;
        // T=0: hold
        tff_t=0; tick();
        assert(tff_q===0) else $error("TFF hold fail");

        // T=1: toggle 0→1
        tff_t=1; tick();
        assert(tff_q===1) else $error("TFF toggle to 1 fail");

        // T=1: toggle 1→0
        tick();
        assert(tff_q===0) else $error("TFF toggle to 0 fail");

        // en=0: should hold even when T=1
        tff_en=0; tff_t=1; tick();
        assert(tff_q===0) else $error("TFF enable=0 hold fail");

        $display("TFF Tests PASSED");
    endtask

    // ---- JKFF Tests ----
    task test_jkff;
        $display("\n--- JK Flip-Flop Tests ---");
        jkff_rst=1; jkff_en=1; jkff_j=0; jkff_k=0; tick();
        assert(jkff_q===0) else $error("JKFF reset fail");
        jkff_rst=0;

        // Hold (J=0, K=0)
        jkff_j=0; jkff_k=0; tick();
        assert(jkff_q===0) else $error("JKFF hold fail");

        // Set (J=1, K=0)
        jkff_j=1; jkff_k=0; tick();
        assert(jkff_q===1) else $error("JKFF set fail");

        // Hold with Q=1
        jkff_j=0; jkff_k=0; tick();
        assert(jkff_q===1) else $error("JKFF hold Q=1 fail");

        // Reset (J=0, K=1)
        jkff_j=0; jkff_k=1; tick();
        assert(jkff_q===0) else $error("JKFF reset fail");

        // Toggle: Set first then toggle
        jkff_j=1; jkff_k=0; tick(); // Q→1
        jkff_j=1; jkff_k=1; tick(); // Toggle → Q=0
        assert(jkff_q===0) else $error("JKFF toggle fail");
        jkff_j=1; jkff_k=1; tick(); // Toggle → Q=1
        assert(jkff_q===1) else $error("JKFF toggle fail");

        // en=0: hold
        jkff_en=0; jkff_j=0; jkff_k=1; tick();
        assert(jkff_q===1) else $error("JKFF enable=0 fail");

        $display("JKFF Tests PASSED");
    endtask

    initial begin
        test_dff;
        test_tff;
        test_jkff;
        $display("\n===== All Flip-Flop Tests Complete =====");
        $finish;
    end

endmodule
