// =============================================================================
// Testbench : shift_registers_tb
// =============================================================================
`timescale 1ns/1ps

module shift_registers_tb;

    localparam WIDTH = 8;

    logic clk = 0;
    always #5 clk = ~clk;

    // ---- SISO ----
    logic siso_rst, siso_en, siso_sin, siso_sout;
    siso_shift_reg #(WIDTH) u_siso (
        .clk, .rst(siso_rst), .en(siso_en),
        .sin(siso_sin), .sout(siso_sout)
    );

    // ---- SIPO ----
    logic sipo_rst, sipo_en, sipo_sin;
    logic [WIDTH-1:0] sipo_pout;
    sipo_shift_reg #(WIDTH) u_sipo (
        .clk, .rst(sipo_rst), .en(sipo_en),
        .sin(sipo_sin), .pout(sipo_pout)
    );

    // ---- PISO ----
    logic piso_rst, piso_en, piso_load, piso_sout;
    logic [WIDTH-1:0] piso_pin;
    piso_shift_reg #(WIDTH) u_piso (
        .clk, .rst(piso_rst), .en(piso_en),
        .load(piso_load), .pin(piso_pin), .sout(piso_sout)
    );

    // ---- PIPO ----
    logic pipo_rst, pipo_en, pipo_mode, pipo_sin, pipo_sout;
    logic [WIDTH-1:0] pipo_pin, pipo_pout;
    pipo_shift_reg #(WIDTH) u_pipo (
        .clk, .rst(pipo_rst), .en(pipo_en),
        .mode(pipo_mode), .pin(pipo_pin), .sin(pipo_sin),
        .pout(pipo_pout), .sout(pipo_sout)
    );

    task tick(); @(posedge clk); #1; endtask

    // ---- SISO Test ----
    task test_siso;
        logic [WIDTH-1:0] pattern = 8'b1011_0010;
        logic sout_captured[];
        $display("\n--- SISO Test: shift in 0xB2, read back serially ---");
        siso_rst=1; siso_en=1; siso_sin=0; tick(); siso_rst=0;
        // Shift in pattern MSB first
        for (int i = WIDTH-1; i >= 0; i--) begin
            siso_sin = pattern[i]; tick();
        end
        // Shift out – next WIDTH clocks output pattern MSB first
        siso_sin = 0;
        begin
            logic [WIDTH-1:0] recv = '0;
            for (int i = WIDTH-1; i >= 0; i--) begin
                recv[i] = siso_sout; tick();
            end
            assert(recv === pattern)
                $display("SISO PASS: recv=0x%02h", recv);
            else
                $error("SISO FAIL: recv=0x%02h exp=0x%02h", recv, pattern);
        end
    endtask

    // ---- SIPO Test ----
    task test_sipo;
        logic [WIDTH-1:0] pattern = 8'hA5;
        $display("\n--- SIPO Test: shift in 0xA5, read parallel ---");
        sipo_rst=1; sipo_en=1; sipo_sin=0; tick(); sipo_rst=0;
        for (int i = WIDTH-1; i >= 0; i--) begin
            sipo_sin = pattern[i]; tick();
        end
        assert(sipo_pout === pattern)
            $display("SIPO PASS: pout=0x%02h", sipo_pout);
        else
            $error("SIPO FAIL: pout=0x%02h exp=0x%02h", sipo_pout, pattern);
    endtask

    // ---- PISO Test ----
    task test_piso;
        logic [WIDTH-1:0] pattern = 8'hC3;
        logic [WIDTH-1:0] recv = '0;
        $display("\n--- PISO Test: load 0xC3, shift out serially ---");
        piso_rst=1; piso_en=1; piso_load=1; piso_pin=pattern; tick();
        piso_rst=0; piso_load=1; tick(); // parallel load
        piso_load=0; // switch to shift mode
        for (int i = WIDTH-1; i >= 0; i--) begin
            recv[i] = piso_sout; tick();
        end
        assert(recv === pattern)
            $display("PISO PASS: recv=0x%02h", recv);
        else
            $error("PISO FAIL: recv=0x%02h exp=0x%02h", recv, pattern);
    endtask

    // ---- PIPO Test ----
    task test_pipo;
        logic [WIDTH-1:0] pattern = 8'hDE;
        $display("\n--- PIPO Test: parallel load 0xDE ---");
        pipo_rst=1; pipo_en=1; pipo_mode=1; pipo_pin=pattern; pipo_sin=0;
        tick(); pipo_rst=0; tick();
        assert(pipo_pout === pattern)
            $display("PIPO PASS (parallel): pout=0x%02h", pipo_pout);
        else
            $error("PIPO FAIL: pout=0x%02h exp=0x%02h", pipo_pout, pattern);

        // Serial shift mode: shift in 8'hFF
        pipo_mode=0;
        for (int i = 0; i < WIDTH; i++) begin
            pipo_sin=1; tick();
        end
        assert(pipo_pout === 8'hFF)
            $display("PIPO PASS (serial): pout=0x%02h", pipo_pout);
        else
            $error("PIPO FAIL serial: pout=0x%02h", pipo_pout);
    endtask

    initial begin
        test_siso;
        test_sipo;
        test_piso;
        test_pipo;
        $display("\n===== All Shift Register Tests Complete =====");
        $finish;
    end

endmodule
