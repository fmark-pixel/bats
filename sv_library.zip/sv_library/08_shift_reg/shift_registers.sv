// =============================================================================
// Module  : siso_shift_reg
// Description : Serial-In Serial-Out (SISO) Shift Register – 8 bits
//               Data shifts LEFT on each rising edge (MSB first out).
//               sout = MSB of the register.
// Synthesisable : YES
// =============================================================================
module siso_shift_reg #(
    parameter int WIDTH = 8
)(
    input  logic clk,
    input  logic rst,    // synchronous active-high reset
    input  logic en,
    input  logic sin,    // serial input (enters at LSB)
    output logic sout    // serial output (exits from MSB)
);
    logic [WIDTH-1:0] sr;

    always_ff @(posedge clk) begin
        if (rst)
            sr <= '0;
        else if (en)
            sr <= {sr[WIDTH-2:0], sin};  // shift left, sin enters at bit[0]
    end

    assign sout = sr[WIDTH-1];  // MSB is serial output

endmodule


// =============================================================================
// Module  : sipo_shift_reg
// Description : Serial-In Parallel-Out (SIPO) Shift Register – 8 bits
//               Data shifts in serially; parallel output always visible.
// Synthesisable : YES
// =============================================================================
module sipo_shift_reg #(
    parameter int WIDTH = 8
)(
    input  logic             clk,
    input  logic             rst,
    input  logic             en,
    input  logic             sin,
    output logic [WIDTH-1:0] pout    // parallel output
);
    always_ff @(posedge clk) begin
        if (rst)
            pout <= '0;
        else if (en)
            pout <= {pout[WIDTH-2:0], sin};  // shift left
    end

endmodule


// =============================================================================
// Module  : piso_shift_reg
// Description : Parallel-In Serial-Out (PISO) Shift Register – 8 bits
//               load=1: loads parallel data on rising edge.
//               load=0: shifts out MSB serially each clock.
// Synthesisable : YES
// =============================================================================
module piso_shift_reg #(
    parameter int WIDTH = 8
)(
    input  logic             clk,
    input  logic             rst,
    input  logic             en,
    input  logic             load,    // 1=parallel load, 0=shift
    input  logic [WIDTH-1:0] pin,     // parallel input
    output logic             sout     // serial output (MSB first)
);
    logic [WIDTH-1:0] sr;

    always_ff @(posedge clk) begin
        if (rst)
            sr <= '0;
        else if (en) begin
            if (load)
                sr <= pin;           // parallel load
            else
                sr <= {sr[WIDTH-2:0], 1'b0};  // shift left, 0 fills LSB
        end
    end

    assign sout = sr[WIDTH-1];

endmodule


// =============================================================================
// Module  : pipo_shift_reg
// Description : Parallel-In Parallel-Out (PIPO) Register – 8 bits
//               On rising edge when en=1: pout captures pin.
//               Also supports serial shift mode when mode=0.
//               mode=1: parallel load; mode=0: serial shift.
// Synthesisable : YES
// =============================================================================
module pipo_shift_reg #(
    parameter int WIDTH = 8
)(
    input  logic             clk,
    input  logic             rst,
    input  logic             en,
    input  logic             mode,    // 1=parallel, 0=serial shift
    input  logic [WIDTH-1:0] pin,
    input  logic             sin,
    output logic [WIDTH-1:0] pout,
    output logic             sout
);
    always_ff @(posedge clk) begin
        if (rst)
            pout <= '0;
        else if (en) begin
            if (mode)
                pout <= pin;                         // parallel in → parallel out
            else
                pout <= {pout[WIDTH-2:0], sin};      // serial shift mode
        end
    end

    assign sout = pout[WIDTH-1];

endmodule
