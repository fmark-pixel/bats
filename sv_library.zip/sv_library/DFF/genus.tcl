
read_libs /home/install/FOUNDRY/digital/180nm/dig/lib/typical.lib
read_hdl DFF.v
elaborate
read_sdc DFF.sdc
syn_generic
syn_map
syn_opt
write_hdl > netlist.v
report_timing > timing.rpt
write_sdc > toolgen.sdc
report_power > power.rpt
report_area > area.rpt
report_gates > gates.rpt
gui_show


