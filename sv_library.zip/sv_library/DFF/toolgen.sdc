# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Fri Mar 27 11:13:59 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design dff

create_clock -name "clk" -period 1.307 -waveform {0.0 0.6535} [get_ports clk]
set_clock_transition 0.0002 [get_clocks clk]
set_load -pin_load 0.15 [get_ports q]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 0.0008 [get_ports d]
set_input_transition 0.0001 [get_ports clk]
set_input_transition 0.0001 [get_ports d]
set_wire_load_mode "enclosed"
