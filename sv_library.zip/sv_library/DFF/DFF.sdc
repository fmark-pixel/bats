
set_unit -capacitance 1000.00fF
set_units -time 1.00ps
create_clock -name clk -period 1307 -waveform {0 653.5} [get_ports clk]
set_clock_transition -rise 0.25 [get_clocks clk]
set_clock_transition -fall 0.25 [get_clocks clk]
set_input_delay -clock clk -max 0.8 [all_inputs]
set_output_delay -clock clk -max 0.5 [all_inputs]
set_input_transition 0.12 [all_inputs]
set_load 0.15 [all_outputs]

