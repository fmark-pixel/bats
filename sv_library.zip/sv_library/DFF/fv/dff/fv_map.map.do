
//input ports
add mapped point clk clk -type PI PI
add mapped point d d -type PI PI

//output ports
add mapped point q q -type PO PO

//inout ports




//Sequential Pins
add mapped point q/q q_reg/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
