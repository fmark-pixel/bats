// =============================================================================
// Testbench : priority_enc8to3_tb
// =============================================================================
`timescale 1ns/1ps

module priority_enc8to3_tb;

    logic [7:0] in;
    logic [2:0] enc;
    logic       valid;

    priority_enc8to3 dut (.*);

    int pass_cnt=0, fail_cnt=0;

    // Reference model: find highest set bit
    function automatic logic [3:0] ref_model(input logic [7:0] v);
        // returns {valid, enc[2:0]}
        for (int i = 7; i >= 0; i--)
            if (v[i]) return {1'b1, i[2:0]};
        return 4'b0_000; // valid=0
    endfunction

    task automatic check(input logic [7:0] tin);
        logic [3:0] exp;
        in = tin; #10;
        exp = ref_model(tin);
        if ({valid, enc} === exp) pass_cnt++;
        else begin
            $error("FAIL | in=%08b | got valid=%0b enc=%0d | exp valid=%0b enc=%0d",
                    tin, valid, enc, exp[3], exp[2:0]);
            fail_cnt++;
        end
    endtask

    initial begin
        $display("===== Priority Encoder 8:3 Testbench =====");

        // Edge: no input
        check(8'b0000_0000);

        // Single bit set (each position)
        for (int i = 0; i < 8; i++) check(8'b1 << i);

        // All ones – highest priority = in[7] → enc=7
        check(8'hFF);

        // Mixed vectors
        check(8'b1010_1010);
        check(8'b0101_0101);
        check(8'b0001_1100);
        check(8'b0000_0011);

        // Random stimulus
        repeat(50) check($urandom_range(0, 255));

        $display("Pass: %0d  Fail: %0d", pass_cnt, fail_cnt);
        $display("===== Test Complete =====");
        $finish;
    end

endmodule
