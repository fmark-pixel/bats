// =============================================================================
// Module  : priority_enc8to3
// Description : 8-to-3 Priority Encoder (active-high inputs)
//               Highest-index asserted input has HIGHEST priority.
//               valid = 0 when no input is asserted.
// Priority    : in[7] > in[6] > ... > in[0]
// Synthesisable : YES
// =============================================================================
module priority_enc8to3 (
    input  logic [7:0] in,
    output logic [2:0] enc,   // encoded output
    output logic       valid  // at least one input asserted
);
    always_comb begin
        valid = 1'b1;
        priority casez (in)
            8'b1???????: enc = 3'd7;
            8'b01??????: enc = 3'd6;
            8'b001?????: enc = 3'd5;
            8'b0001????: enc = 3'd4;
            8'b00001???: enc = 3'd3;
            8'b000001??: enc = 3'd2;
            8'b0000001?: enc = 3'd1;
            8'b00000001: enc = 3'd0;
            default:     begin enc = 3'd0; valid = 1'b0; end
        endcase
    end

endmodule
