# SystemVerilog Combinational & Sequential Design Library
## Synthesisable RTL + Self-Checking Testbenches

---

## Directory Structure

```
sv_library/
├── 01_full_adder/
│   ├── full_adder.sv          ← 1-bit Full Adder
│   └── full_adder_tb.sv       ← Exhaustive 8-vector test
│
├── 02_rca_4bit/
│   ├── rca_4bit.sv            ← 4-bit Ripple Carry Adder (4× FA)
│   └── rca_4bit_tb.sv         ← Directed + 50 random vectors
│
├── 03_mux/
│   ├── mux.sv                 ← 4:1 MUX + 8:1 MUX (built from 4:1)
│   └── mux_tb.sv              ← Exhaustive for both
│
├── 04_demux/
│   ├── demux1to4.sv           ← 1:4 DEMUX with active-high enable
│   └── demux1to4_tb.sv
│
├── 05_priority_enc/
│   ├── priority_enc8to3.sv    ← 8:3 Priority Encoder (valid flag)
│   └── priority_enc8to3_tb.sv ← Ref-model + random
│
├── 06_dec3to8/
│   ├── dec3to8.sv             ← 3-to-8 One-Hot Decoder
│   └── dec3to8_tb.sv
│
├── 07_flipflops/
│   ├── flipflops.sv           ← D-FF, T-FF, JK-FF (sync reset + enable)
│   └── flipflops_tb.sv
│
├── 08_shift_reg/
│   ├── shift_registers.sv     ← SISO, SIPO, PISO, PIPO (WIDTH param)
│   └── shift_registers_tb.sv
│
└── 09_counter/
    ├── counter.sv             ← Up/Down Counter + Mod-N Counter
    └── counter_tb.sv
```

---

## Module Quick Reference

| # | Module | Key Ports | Notes |
|---|--------|-----------|-------|
| 1 | `full_adder` | a, b, cin → sum, cout | Structural gates |
| 2 | `rca_4bit` | a[3:0], b[3:0], cin → sum[3:0], cout | 4× `full_adder` instances |
| 3 | `mux4to1` | d[3:0], sel[1:0] → out | `assign out = d[sel]` |
| 3 | `mux8to1` | d[7:0], sel[2:0] → out | 2× `mux4to1` + final mux |
| 4 | `demux1to4` | in, sel[1:0], en → out[3:0] | Active-high enable |
| 5 | `priority_enc8to3` | in[7:0] → enc[2:0], valid | `priority casez` |
| 6 | `dec3to8` | addr[2:0], en → out[7:0] | One-hot; `1 << addr` |
| 7 | `dff` | clk, rst, en, d → q, q_n | Sync reset, CE |
| 7 | `tff` | clk, rst, en, t → q, q_n | D = T⊕Q |
| 7 | `jkff` | clk, rst, en, j, k → q, q_n | casez(j,k) |
| 8 | `siso_shift_reg` | sin → sout | 8-bit, param WIDTH |
| 8 | `sipo_shift_reg` | sin → pout[W-1:0] | |
| 8 | `piso_shift_reg` | load, pin → sout | |
| 8 | `pipo_shift_reg` | mode, pin/sin → pout/sout | mode: parallel/serial |
| 9 | `updown_counter` | dir, load, din → cnt, tc | param WIDTH |
| 9 | `mod_n_counter` | — → cnt, tc | param MOD, WIDTH=$clog2(MOD) |

---

## Simulation (Icarus Verilog / iVerilog)

```bash
# Example: Full Adder
cd 01_full_adder
iverilog -g2012 -o sim full_adder.sv full_adder_tb.sv && vvp sim

# Example: 4-bit RCA (depends on full_adder.sv)
cd 02_rca_4bit
iverilog -g2012 -o sim full_adder.sv rca_4bit.sv rca_4bit_tb.sv && vvp sim

# Example: MUX (mux8to1 depends on mux4to1)
cd 03_mux
iverilog -g2012 -o sim mux.sv mux_tb.sv && vvp sim

# Example: Counters
cd 09_counter
iverilog -g2012 -o sim counter.sv counter_tb.sv && vvp sim
```

---

## Simulation (Synopsys VCS / Cadence Xcelium)

```bash
# VCS
vcs -sverilog full_adder.sv full_adder_tb.sv -o simv && ./simv

# Xcelium
xrun -sv full_adder.sv full_adder_tb.sv
```

---

## Design Notes

### Reset Strategy
All sequential modules use **synchronous active-high reset**. To switch to asynchronous:
```systemverilog
// Change:
always_ff @(posedge clk) begin
    if (rst) ...

// To:
always_ff @(posedge clk or posedge rst) begin
    if (rst) ...
```

### Priority Encoder — `casez` vs `unique case`
`priority casez` is used intentionally. `unique casez` would generate warnings
for overlapping patterns (e.g. `8'b1???????` matches multiple inputs).

### Mod-N Counter WIDTH
`WIDTH` defaults to `$clog2(MOD)` which is the minimum number of bits needed.
Override it if you need a wider bus (e.g. connecting to a wider datapath).

### Shift Register Polarity
All shift registers shift **left** (new data enters at bit[0], exits at MSB).
To shift right, change `{sr[WIDTH-2:0], sin}` → `{sin, sr[WIDTH-1:1]}`.
